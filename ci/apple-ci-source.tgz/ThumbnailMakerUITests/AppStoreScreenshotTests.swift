//
//  AppStoreScreenshotTests.swift
//  ThumbnailMakerUITests
//

import XCTest
import UIKit

final class AppStoreScreenshotTests: XCTestCase {

    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    override func tearDownWithError() throws {
        XCUIDevice.shared.orientation = .portrait
    }

    @MainActor
    func testIPhoneEditorAndTemplateScreenshots() throws {
        guard UIDevice.current.userInterfaceIdiom == .phone else {
            throw XCTSkip("Requires an iPhone simulator.")
        }

        let app = launchApp([
            "-UITestSeedSelectedImage",
            "-DisableDraftPersistence"
        ])

        XCTAssertTrue(app.navigationBars["Simple Maker"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.descendants(matching: .any)["layerSelectionStrip"].waitForExistence(timeout: 5))
        attachScreenshot(named: "01-iphone-editor-wysiwyg")

        let templatesButton = app.buttons["Templates"]
        XCTAssertTrue(templatesButton.waitForExistence(timeout: 5))
        templatesButton.tap()

        XCTAssertTrue(app.navigationBars["Templates"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.descendants(matching: .any)["templateCard-youtube-bold-launch"].waitForExistence(timeout: 5))
        attachScreenshot(named: "02-iphone-template-gallery")

        app.descendants(matching: .any)["templateCard-youtube-bold-launch"].tap()
        XCTAssertTrue(app.staticTexts["BIG REVEAL"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.descendants(matching: .any)["layerSelectionStrip"].waitForExistence(timeout: 5))
        assertTextManipulationHandlesAreUsable(in: app)
        attachScreenshot(named: "03-iphone-template-applied")
    }

    @MainActor
    func testIPhoneAIAndExportScreenshots() throws {
        guard UIDevice.current.userInterfaceIdiom == .phone else {
            throw XCTSkip("Requires an iPhone simulator.")
        }

        let app = launchApp([
            "-UITestSeedDenseTitle",
            "-DisableDraftPersistence"
        ])

        let titleIdeasLabel = app.descendants(matching: .any)["titleIdeasLabel"]
        scrollToHittable(titleIdeasLabel, in: app, maxSwipes: 8)
        XCTAssertTrue(titleIdeasLabel.waitForExistence(timeout: 5))
        attachScreenshot(named: "04-iphone-ai-title-ideas")

        let checkButton = app.descendants(matching: .any)["checkExportSizeButton"]
        scrollToHittable(checkButton, in: app, maxSwipes: 8)
        XCTAssertTrue(checkButton.waitForExistence(timeout: 5))
        checkButton.tap()

        XCTAssertTrue(app.descendants(matching: .any)["exportFileSizeLabel"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.descendants(matching: .any)["creatorReadinessLabel"].waitForExistence(timeout: 5))
        attachScreenshot(named: "05-iphone-export-readiness")
    }

    @MainActor
    func testIPadRegularLayoutScreenshots() throws {
        guard UIDevice.current.userInterfaceIdiom == .pad else {
            throw XCTSkip("Requires an iPad simulator.")
        }

        let launchArguments = [
            "-UITestUnlockPremium",
            "-UITestSeedSelectedImage",
            "-UITestSeedPremiumEditor",
            "-DisableDraftPersistence"
        ]
        let app = launchApp(launchArguments)

        let simpleRegularLayout = app.descendants(matching: .any)["simpleRegularEditorLayout"]
        XCTAssertTrue(simpleRegularLayout.waitForExistence(timeout: 5))
        XCTAssertFalse(app.descendants(matching: .any)["simpleCompactEditorLayout"].exists)
        attachScreenshot(named: "01-ipad-simple-regular-editor")

        let premiumTabButton = app.buttons
            .matching(NSPredicate(format: "label == %@", "Premium"))
            .firstMatch
        XCTAssertTrue(premiumTabButton.waitForExistence(timeout: 5))
        tap(premiumTabButton)

        let premiumRegularLayout = app.descendants(matching: .any)["premiumRegularEditorLayout"]
        XCTAssertTrue(premiumRegularLayout.waitForExistence(timeout: 5))
        XCTAssertFalse(app.descendants(matching: .any)["premiumCompactEditorLayout"].exists)
        attachScreenshot(named: "02-ipad-premium-regular-editor")

        app.terminate()
        XCUIDevice.shared.orientation = .landscapeRight

        let landscapeApp = launchApp(launchArguments)
        guard waitForLandscape(landscapeApp) else {
            XCTFail("Simulator never entered landscape; iPad landscape screenshot not captured")
            return
        }

        let landscapePremiumTabButton = landscapeApp.buttons
            .matching(NSPredicate(format: "label == %@", "Premium"))
            .firstMatch
        XCTAssertTrue(landscapePremiumTabButton.waitForExistence(timeout: 5))
        tap(landscapePremiumTabButton)

        let landscapePremiumRegularLayout = landscapeApp.descendants(matching: .any)["premiumRegularEditorLayout"]
        XCTAssertTrue(landscapePremiumRegularLayout.waitForExistence(timeout: 5))
        XCTAssertFalse(landscapeApp.descendants(matching: .any)["premiumCompactEditorLayout"].exists)
        attachScreenshot(named: "03-ipad-premium-landscape-editor")
    }

    private func launchApp(_ arguments: [String]) -> XCUIApplication {
        let app = XCUIApplication()
        app.launchArguments = arguments
        app.launch()
        return app
    }

    private func assertTextManipulationHandlesAreUsable(in app: XCUIApplication) {
        for identifier in ["textFlipHandle", "textRotateHandle", "textResizeHandle"] {
            let handle = app.descendants(matching: .any)[identifier]
            XCTAssertTrue(handle.waitForExistence(timeout: 5), "\(identifier) should exist on the selected text layer")
            XCTAssertTrue(handle.isHittable, "\(identifier) should remain hittable after chrome positioning")
        }
    }

    private func attachScreenshot(named name: String) {
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = name
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }

    private func scrollToHittable(
        _ element: XCUIElement,
        in app: XCUIApplication,
        maxSwipes: Int
    ) {
        for _ in 0..<maxSwipes where !element.isHittable {
            app.swipeUp()
        }
    }

    private func tap(_ element: XCUIElement) {
        if element.isHittable {
            element.tap()
        } else {
            element.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
        }
    }

    private func waitForLandscape(_ app: XCUIApplication) -> Bool {
        let deadline = Date().addingTimeInterval(8)
        while app.frame.width <= app.frame.height && Date() < deadline {
            XCUIDevice.shared.orientation = .landscapeRight
            RunLoop.current.run(until: Date().addingTimeInterval(0.2))
        }
        return app.frame.width > app.frame.height
    }
}
