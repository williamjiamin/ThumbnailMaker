//
//  BrandKit.swift
//  ThumbnailMaker
//

import Foundation
import SwiftUI

struct BrandColor: Codable, Equatable, Identifiable {
    var id: String
    var name: String
    var color: ThumbnailDocumentColor

    init(id: String, name: String, color: ThumbnailDocumentColor) {
        self.id = id
        self.name = name
        self.color = color
    }
}

struct BrandKit: Codable, Equatable, Identifiable {
    static let currentVersion = 1

    var version = currentVersion
    var id: String
    var name: String
    var palette: [BrandColor]
    var primaryFontRawValue: String
    var secondaryFontRawValue: String?
    var logoImageData: Data?
    var updatedAt: Date

    init(
        version: Int = BrandKit.currentVersion,
        id: String,
        name: String,
        palette: [BrandColor] = [],
        primaryFontRawValue: String = CustomFont.goNoto.rawValue,
        secondaryFontRawValue: String? = nil,
        logoImageData: Data? = nil,
        updatedAt: Date = Date()
    ) {
        self.version = version
        self.id = id
        self.name = name
        self.palette = palette
        self.primaryFontRawValue = primaryFontRawValue
        self.secondaryFontRawValue = secondaryFontRawValue
        self.logoImageData = logoImageData
        self.updatedAt = updatedAt
    }

    private enum CodingKeys: String, CodingKey {
        case version
        case id
        case name
        case palette
        case primaryFontRawValue
        case secondaryFontRawValue
        case logoImageData
        case updatedAt
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let decodedVersion = try container.decodeIfPresent(Int.self, forKey: .version) ?? Self.currentVersion

        version = max(decodedVersion, Self.currentVersion)
        id = try container.decode(String.self, forKey: .id)
        name = try container.decode(String.self, forKey: .name)
        palette = try container.decodeIfPresent([BrandColor].self, forKey: .palette) ?? []
        primaryFontRawValue = try container.decodeIfPresent(
            String.self,
            forKey: .primaryFontRawValue
        ) ?? CustomFont.goNoto.rawValue
        secondaryFontRawValue = try container.decodeIfPresent(String.self, forKey: .secondaryFontRawValue)
        logoImageData = try container.decodeIfPresent(Data.self, forKey: .logoImageData)
        updatedAt = try container.decodeIfPresent(Date.self, forKey: .updatedAt) ?? Date(timeIntervalSince1970: 0)
    }
}

extension BrandKit {
    static func defaultCreatorKit(id: String = UUID().uuidString) -> BrandKit {
        BrandKit(
            id: id,
            name: "Creator Brand",
            palette: [
                BrandColor(
                    id: "\(id)-text",
                    name: "Text",
                    color: ThumbnailDocumentColor(color: .white)
                ),
                BrandColor(
                    id: "\(id)-background",
                    name: "Background",
                    color: ThumbnailDocumentColor(
                        red: 18.0 / 255.0,
                        green: 26.0 / 255.0,
                        blue: 38.0 / 255.0,
                        alpha: 1
                    )
                )
            ],
            primaryFontRawValue: CustomFont.montserrat.rawValue,
            secondaryFontRawValue: CustomFont.openSans.rawValue
        )
    }

    var primaryFont: CustomFont {
        CustomFont(rawValue: primaryFontRawValue) ?? .goNoto
    }

    var secondaryFont: CustomFont? {
        secondaryFontRawValue.flatMap(CustomFont.init(rawValue:))
    }

    func applied(to configuration: SimpleMakerConfigurationModel) -> SimpleMakerConfigurationModel {
        var configuration = configuration
        applySharedStyle(to: &configuration)
        return configuration
    }

    func applied(to configuration: PremiumMakerConfigurationModel) -> PremiumMakerConfigurationModel {
        var configuration = configuration
        applySharedStyle(to: &configuration)
        return configuration
    }

    private func applySharedStyle(to configuration: inout SimpleMakerConfigurationModel) {
        if let textColor = palette.first?.color.color {
            configuration.textColor = textColor
        }

        if let backgroundColor = palette.dropFirst().first?.color.color {
            configuration.backgroundColor = backgroundColor
        }

        configuration.selectedFont = primaryFont
        configuration.usesFallbackFont = false
    }

    private func applySharedStyle(to configuration: inout PremiumMakerConfigurationModel) {
        if let textColor = palette.first?.color.color {
            configuration.textColor = textColor
        }

        if let backgroundColor = palette.dropFirst().first?.color.color {
            configuration.backgroundColor = backgroundColor
        }

        configuration.selectedFont = primaryFont
        configuration.usesFallbackFont = false
    }
}
