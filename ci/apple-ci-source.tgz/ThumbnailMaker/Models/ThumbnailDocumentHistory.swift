//
//  ThumbnailDocumentHistory.swift
//  ThumbnailMaker
//

import Foundation

struct ThumbnailDocumentHistory: Equatable {
    private(set) var undoStack: [ThumbnailDocument] = []
    private(set) var redoStack: [ThumbnailDocument] = []
    var limit = 20

    var canUndo: Bool {
        !undoStack.isEmpty
    }

    var canRedo: Bool {
        !redoStack.isEmpty
    }

    mutating func record(_ previous: ThumbnailDocument) {
        let snapshot = Self.snapshot(previous)
        guard undoStack.last != snapshot else { return }

        undoStack.append(snapshot)
        trimUndoStack()
        redoStack.removeAll()
    }

    mutating func undo(current: ThumbnailDocument) -> ThumbnailDocument? {
        guard let previous = undoStack.popLast() else { return nil }

        redoStack.append(Self.snapshot(current))
        trimRedoStack()
        return previous
    }

    mutating func redo(current: ThumbnailDocument) -> ThumbnailDocument? {
        guard let next = redoStack.popLast() else { return nil }

        undoStack.append(Self.snapshot(current))
        trimUndoStack()
        return next
    }

    static func snapshot(_ document: ThumbnailDocument) -> ThumbnailDocument {
        var snapshot = document
        snapshot.updatedAt = Date(timeIntervalSince1970: 0)
        return snapshot
    }

    private mutating func trimUndoStack() {
        while undoStack.count > limit {
            undoStack.removeFirst()
        }
    }

    private mutating func trimRedoStack() {
        while redoStack.count > limit {
            redoStack.removeFirst()
        }
    }
}
