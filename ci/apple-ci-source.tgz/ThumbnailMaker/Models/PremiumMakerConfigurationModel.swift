//
//  PremiumMakerConfigurationModel.swift
//  ThumbnailMaker
//
//  Created by william on 2024/11/28.
//

import Foundation
import SwiftUI

struct PremiumMakerConfigurationModel {
    var selectedImage: UIImage?
    var overlayText: String = ""
    var selectedRatio: AspectRatio = .ratio16_9
    var backgroundColor: Color = Color(uiColor: .secondarySystemBackground)
    var textColor: Color = .white
    var textSize: CGFloat = 0.15
    var verticalAlignment: VerticalAlignment = .center
    var horizontalAlignment: HorizontalAlignment = .center
    var textTransform = ThumbnailOverlayTransform.centered
    var circularProfile: CircularProfileConfig?
    var profileTransform = ThumbnailOverlayTransform.profileDefault
    var macroConfig: MacroConfig = MacroConfig()
    var selectedFont: CustomFont = .goNoto
    var usesFallbackFont: Bool = false
    var layers: [ThumbnailDocumentLayer] = ThumbnailDocumentLayer.defaultLayers(
        hasText: false,
        hasProfile: false
    )
    var exportOptions = ThumbnailExportOptions()
}

extension PremiumMakerConfigurationModel {
    init(document: ThumbnailDocument) {
        self = document.makePremiumConfiguration()
    }

    var document: ThumbnailDocument {
        ThumbnailDocument(configuration: self)
    }
}
