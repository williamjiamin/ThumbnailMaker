//
//  SimpleMakerViewModel.swift
//  ThumbnailMaker
//
//  Created by william on 2024/11/28.
//

import PhotosUI
import SwiftUI

@MainActor
class SimpleMakerViewModel: ObservableObject {
    @Published var simpleMakerConfiguration = SimpleMakerConfigurationModel() {
        didSet {
            scheduleDraftAutosave()
        }
    }
    @Published var imageSelection: PhotosPickerItem?
    @Published var layerImageSelection: PhotosPickerItem?
    @Published var stickerImageSelection: PhotosPickerItem?
    @Published var saveError: String?
    @Published var showingSaveAlert = false
    @Published var isSaving = false
    @Published var isPreparingShare = false
    @Published var isPreparingFileExport = false
    @Published var isCheckingExportSize = false
    @Published var isProcessingSubject = false
    @Published var isPermissionError = false
    @Published var shareItem: ThumbnailShareItem?
    @Published var fileExport: ThumbnailPreparedFileExport?
    @Published var isFileExporterPresented = false
    @Published var exportReport: ThumbnailExportReport?
    @Published var successMessage = "Thumbnail saved to Photos"
    @Published private(set) var brandKit: BrandKit?
    @Published private(set) var restoredDraft = false
    @Published private(set) var canUndo = false
    @Published private(set) var canRedo = false
    
    let usableHeightProportion: CGFloat = 0.6
    let previewHeightProportion: CGFloat = 0.35
    let overlayCharacterLimit = 120
    private let draftStore: ThumbnailDraftStore
    private let brandKitStore: BrandKitStore
    private var isDraftPersistenceEnabled = true
    private var pendingDraftSave: DispatchWorkItem?
    private var history = ThumbnailDocumentHistory()
    private var historyBaseline = ThumbnailDocumentHistory.snapshot(SimpleMakerConfigurationModel().document)
    private var isApplyingHistory = false
    private var isHistoryTrackingEnabled = false
    private let suggestionProvider = LocalThumbnailSuggestionProvider()
    private let ideaProvider = LocalThumbnailIdeaProvider()
    private let subjectProcessor: ThumbnailSubjectProcessing

    var actionableSuggestions: [ThumbnailSuggestion] {
        suggestionProvider.suggestions(
            for: simpleMakerConfiguration,
            brandKit: brandKit,
            templates: ThumbnailTemplate.builtIns
        )
        .filter(isActionableSuggestion)
    }

    var titleIdeas: [ThumbnailIdea] {
        ideaProvider.ideas(
            forTitle: simpleMakerConfiguration.overlayText,
            ratio: simpleMakerConfiguration.selectedRatio,
            brandKit: brandKit,
            templates: ThumbnailTemplate.builtIns
        )
    }

    var selectableLayerSelections: [ThumbnailLayerSelection] {
        simpleMakerConfiguration.layers.selectableLayerSelections(
            hasText: !simpleMakerConfiguration.overlayText.isEmpty,
            hasProfile: false
        )
    }

    var hasExportableContent: Bool {
        simpleMakerConfiguration.selectedImage != nil
            || !simpleMakerConfiguration.overlayText.isEmpty
            || simpleMakerConfiguration.layers.hasContentLayers
    }

    func reconcileLayersForCurrentOverlays() {
        let reconciledLayers = simpleMakerConfiguration.layers.reconciledForCurrentOverlays(
            hasText: !simpleMakerConfiguration.overlayText.isEmpty,
            hasProfile: false
        )

        if reconciledLayers != simpleMakerConfiguration.layers {
            simpleMakerConfiguration.layers = reconciledLayers
        }
    }

    func toggleLayerVisibility(_ selection: ThumbnailLayerSelection) {
        var configuration = simpleMakerConfiguration
        configuration.layers = configuration.layers.reconciledForCurrentOverlays(
            hasText: !configuration.overlayText.isEmpty,
            hasProfile: false
        )
        configuration.layers.toggleVisibility(for: selection)
        simpleMakerConfiguration = configuration
    }

    func toggleLayerLock(_ selection: ThumbnailLayerSelection) {
        var configuration = simpleMakerConfiguration
        configuration.layers = configuration.layers.reconciledForCurrentOverlays(
            hasText: !configuration.overlayText.isEmpty,
            hasProfile: false
        )
        configuration.layers.toggleLock(for: selection)
        simpleMakerConfiguration = configuration
    }

    func canRemoveBackground(from selection: ThumbnailLayerSelection) -> Bool {
        if case .content(let layerID) = selection,
           let layer = simpleMakerConfiguration.layers.record(id: layerID),
           case .image = layer.content {
            return true
        }

        return simpleMakerConfiguration.selectedImage != nil
    }

    init(
        draftStore: ThumbnailDraftStore = ThumbnailDraftStore(),
        brandKitStore: BrandKitStore = BrandKitStore(),
        subjectProcessor: ThumbnailSubjectProcessing = BackgroundRemovalService()
    ) {
        self.draftStore = draftStore
        self.brandKitStore = brandKitStore
        self.subjectProcessor = subjectProcessor

        let launchArguments = ProcessInfo.processInfo.arguments
        if launchArguments.contains("-DisableDraftPersistence") {
            isDraftPersistenceEnabled = false
        }

        if isDraftPersistenceEnabled {
            brandKit = try? brandKitStore.load()
        }

        #if DEBUG
        if launchArguments.contains("-UITestSeedDenseTitle") {
            isDraftPersistenceEnabled = false
            simpleMakerConfiguration.overlayText = "This is a very long thumbnail title with too many words for tiny previews"
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }

        if launchArguments.contains("-UITestSeedSelectedImage") {
            isDraftPersistenceEnabled = false
            simpleMakerConfiguration.selectedImage = Self.makeUITestImage()
            simpleMakerConfiguration.overlayText = "Readable title"
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }

        if launchArguments.contains("-UITestSeedTopEdgeText") {
            isDraftPersistenceEnabled = false
            simpleMakerConfiguration.selectedImage = Self.makeUITestImage()
            simpleMakerConfiguration.overlayText = "Edge title"
            simpleMakerConfiguration.textTransform = ThumbnailOverlayTransform(
                x: 0.5,
                y: 0.18,
                rotationDegrees: -4
            )
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }

        if launchArguments.contains("-UITestSeedImageLayer") {
            isDraftPersistenceEnabled = false
            simpleMakerConfiguration.selectedImage = Self.makeUITestImage()
            simpleMakerConfiguration.overlayText = "Layered"
            if let layerImageData = Self.makeUITestLayerImage().pngData() {
                simpleMakerConfiguration.layers.addImageLayer(
                    imageData: layerImageData,
                    id: "ui-test-image-layer",
                    transform: ThumbnailOverlayTransform(
                        x: 0.64,
                        y: 0.48,
                        rotationDegrees: 7
                    ),
                    size: 0.28
                )
            }
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }

        if launchArguments.contains("-UITestSeedStickerLayer") {
            isDraftPersistenceEnabled = false
            simpleMakerConfiguration.selectedImage = Self.makeUITestImage()
            simpleMakerConfiguration.overlayText = "Sticker"
            if let stickerImageData = Self.makeUITestLayerImage().pngData() {
                simpleMakerConfiguration.layers.addStickerLayer(
                    imageData: stickerImageData,
                    id: "ui-test-sticker-layer",
                    transform: ThumbnailOverlayTransform(
                        x: 0.62,
                        y: 0.44,
                        rotationDegrees: -4
                    ),
                    size: 0.24
                )
            }
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }

        if launchArguments.contains("-UITestSeedReorderLayers") {
            isDraftPersistenceEnabled = false
            simpleMakerConfiguration.selectedImage = Self.makeUITestImage()
            simpleMakerConfiguration.overlayText = ""
            if let layerImageData = Self.makeUITestLayerImage().pngData() {
                simpleMakerConfiguration.layers.addImageLayer(
                    imageData: layerImageData,
                    id: "ui-test-reorder-image-layer",
                    transform: ThumbnailOverlayTransform(x: 0.38, y: 0.48),
                    size: 0.22
                )
            }
            simpleMakerConfiguration.layers.addShapeLayer(
                shapeKind: .rectangle,
                id: "ui-test-reorder-shape-layer",
                fillColor: ThumbnailDocumentColor(red: 1, green: 0.72, blue: 0.12, alpha: 1),
                strokeColor: ThumbnailDocumentColor(red: 1, green: 1, blue: 1, alpha: 1),
                strokeWidth: 0.018,
                transform: ThumbnailOverlayTransform(x: 0.62, y: 0.48),
                width: 0.24,
                height: 0.18
            )
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }

        if launchArguments.contains("-UITestSeedCenteringLayer") {
            isDraftPersistenceEnabled = false
            simpleMakerConfiguration.selectedImage = Self.makeUITestImage()
            simpleMakerConfiguration.overlayText = ""
            if let layerImageData = Self.makeUITestLayerImage().pngData() {
                simpleMakerConfiguration.layers.addImageLayer(
                    imageData: layerImageData,
                    id: "ui-test-centering-layer",
                    transform: ThumbnailOverlayTransform(x: 0.52, y: 0.52),
                    size: 0.24
                )
            }
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }

        if launchArguments.contains("-UITestSeedTopEdgeImageLayer") {
            isDraftPersistenceEnabled = false
            simpleMakerConfiguration.selectedImage = Self.makeUITestImage()
            simpleMakerConfiguration.overlayText = "Image edge"
            if let layerImageData = Self.makeUITestLayerImage().pngData() {
                simpleMakerConfiguration.layers.addImageLayer(
                    imageData: layerImageData,
                    id: "ui-test-edge-image-layer",
                    transform: ThumbnailOverlayTransform(
                        x: 0.5,
                        y: 0.1,
                        rotationDegrees: -6
                    ),
                    size: 0.44
                )
            }
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }

        if launchArguments.contains("-UITestSeedShapeLayer") {
            isDraftPersistenceEnabled = false
            simpleMakerConfiguration.selectedImage = Self.makeUITestImage()
            simpleMakerConfiguration.overlayText = "Shape"
            simpleMakerConfiguration.layers.addShapeLayer(
                shapeKind: .ellipse,
                id: "ui-test-shape-layer",
                fillColor: ThumbnailDocumentColor(red: 0.96, green: 0.22, blue: 0.30, alpha: 1),
                strokeColor: ThumbnailDocumentColor(red: 1, green: 1, blue: 1, alpha: 1),
                strokeWidth: 0.018,
                transform: ThumbnailOverlayTransform(
                    x: 0.66,
                    y: 0.44,
                    rotationDegrees: -8
                ),
                width: 0.22,
                height: 0.18
            )
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }

        if launchArguments.contains("-UITestSeedTextLayer") {
            isDraftPersistenceEnabled = false
            simpleMakerConfiguration.selectedImage = Self.makeUITestImage()
            simpleMakerConfiguration.overlayText = "Base title"
            simpleMakerConfiguration.layers.addTextLayer(
                value: "Layer Text",
                id: "ui-test-text-layer",
                color: ThumbnailDocumentColor(red: 1, green: 0.92, blue: 0.18, alpha: 1),
                size: 0.15,
                selectedFontRawValue: CustomFont.montserrat.rawValue,
                transform: ThumbnailOverlayTransform(
                    x: 0.58,
                    y: 0.42,
                    rotationDegrees: 6
                )
            )
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }

        if launchArguments.contains("-UITestSeedTopEdgeShapeLayer") {
            isDraftPersistenceEnabled = false
            simpleMakerConfiguration.selectedImage = Self.makeUITestImage()
            simpleMakerConfiguration.overlayText = "Shape edge"
            simpleMakerConfiguration.layers.addShapeLayer(
                shapeKind: .rectangle,
                id: "ui-test-edge-shape-layer",
                fillColor: ThumbnailDocumentColor(red: 1, green: 0.72, blue: 0.1, alpha: 1),
                strokeColor: ThumbnailDocumentColor(red: 1, green: 1, blue: 1, alpha: 1),
                strokeWidth: 0.018,
                transform: ThumbnailOverlayTransform(
                    x: 0.5,
                    y: 0.1,
                    rotationDegrees: 5
                ),
                width: 0.42,
                height: 0.24
            )
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }
        #endif

        if isDraftPersistenceEnabled {
            restoreDraftIfAvailable()
        }

        resetHistoryBaseline()
        isHistoryTrackingEnabled = true
    }
    
    func updateImage() async {
        if let data = try? await imageSelection?.loadTransferable(type: Data.self),
           let uiImage = UIImage(data: data) {
            await MainActor.run {
                simpleMakerConfiguration.selectedImage = uiImage
            }
        }
    }

    func addImageLayerFromSelection() async -> ThumbnailLayerSelection? {
        defer {
            layerImageSelection = nil
        }

        guard let data = try? await layerImageSelection?.loadTransferable(type: Data.self),
              UIImage(data: data) != nil else {
            return nil
        }

        return addImageLayer(imageData: data)
    }

    func addStickerLayerFromSelection() async -> ThumbnailLayerSelection? {
        defer {
            stickerImageSelection = nil
        }

        guard let data = try? await stickerImageSelection?.loadTransferable(type: Data.self),
              UIImage(data: data) != nil else {
            return nil
        }

        return addStickerLayer(imageData: data)
    }

    @discardableResult
    func addImageLayer(imageData: Data) -> ThumbnailLayerSelection {
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        isApplyingHistory = true
        let layerID = simpleMakerConfiguration.layers.addImageLayer(imageData: imageData)
        finishImmediateEditorMutation(previousDocument: previousDocument)
        return .content(layerID)
    }

    @discardableResult
    func addStickerLayer(imageData: Data) -> ThumbnailLayerSelection {
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        isApplyingHistory = true
        let layerID = simpleMakerConfiguration.layers.addStickerLayer(imageData: imageData)
        finishImmediateEditorMutation(previousDocument: previousDocument)
        return .content(layerID)
    }

    @discardableResult
    func addTextLayer(value: String = "New text") -> ThumbnailLayerSelection {
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        isApplyingHistory = true
        let layerID = simpleMakerConfiguration.layers.addTextLayer(
            value: value,
            color: ThumbnailDocumentColor(color: simpleMakerConfiguration.textColor),
            size: Double(simpleMakerConfiguration.textSize),
            selectedFontRawValue: simpleMakerConfiguration.selectedFont.rawValue,
            transform: simpleMakerConfiguration.textTransform
        )
        finishImmediateEditorMutation(previousDocument: previousDocument)
        return .content(layerID)
    }

    @discardableResult
    func addShapeLayer(_ shapeKind: ThumbnailShapeKind) -> ThumbnailLayerSelection {
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        isApplyingHistory = true
        let layerID = simpleMakerConfiguration.layers.addShapeLayer(shapeKind: shapeKind)
        finishImmediateEditorMutation(previousDocument: previousDocument)
        return .content(layerID)
    }

    func duplicateLayer(_ selection: ThumbnailLayerSelection) -> ThumbnailLayerSelection? {
        guard case .content(let layerID) = selection else { return nil }
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        isApplyingHistory = true
        guard let duplicatedLayerID = simpleMakerConfiguration.layers.duplicateContentLayer(id: layerID) else {
            isApplyingHistory = false
            return nil
        }
        finishImmediateEditorMutation(previousDocument: previousDocument)
        return .content(duplicatedLayerID)
    }

    func moveLayerBackward(
        _ selection: ThumbnailLayerSelection,
        within selections: [ThumbnailLayerSelection]
    ) {
        guard simpleMakerConfiguration.layers.canMoveBackward(selection, within: selections) else { return }
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        isApplyingHistory = true
        simpleMakerConfiguration.layers.moveBackward(selection, within: selections)
        finishImmediateEditorMutation(previousDocument: previousDocument)
    }

    func moveLayerForward(
        _ selection: ThumbnailLayerSelection,
        within selections: [ThumbnailLayerSelection]
    ) {
        guard simpleMakerConfiguration.layers.canMoveForward(selection, within: selections) else { return }
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        isApplyingHistory = true
        simpleMakerConfiguration.layers.moveForward(selection, within: selections)
        finishImmediateEditorMutation(previousDocument: previousDocument)
    }

    func deleteLayer(_ selection: ThumbnailLayerSelection) -> ThumbnailLayerSelection? {
        guard case .content(let layerID) = selection else { return nil }
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        isApplyingHistory = true
        simpleMakerConfiguration.layers.deleteContentLayer(id: layerID)
        finishImmediateEditorMutation(previousDocument: previousDocument)
        return selectableLayerSelections.last
    }

    func restoreDraftIfAvailable() {
        do {
            guard let draftConfiguration = try draftStore.load() else { return }
            simpleMakerConfiguration = draftConfiguration
            restoredDraft = true
            if isHistoryTrackingEnabled {
                resetHistoryBaseline()
            }
        } catch {
            print("Failed to restore Simple Maker draft: \(error.localizedDescription)")
        }
    }

    func saveDraftNow() {
        guard isDraftPersistenceEnabled else { return }

        do {
            try draftStore.save(simpleMakerConfiguration)
        } catch {
            print("Failed to save Simple Maker draft: \(error.localizedDescription)")
        }
    }

    func saveBrandKit(_ kit: BrandKit?) {
        brandKit = kit
        guard isDraftPersistenceEnabled else { return }

        do {
            if let kit {
                try brandKitStore.save(kit)
            } else {
                try brandKitStore.delete()
            }
        } catch {
            saveError = "Failed to save brand kit: \(error.localizedDescription)"
            showingSaveAlert = true
        }
    }

    private func scheduleDraftAutosave() {
        guard isHistoryTrackingEnabled, !isApplyingHistory else { return }

        pendingDraftSave?.cancel()

        let workItem = DispatchWorkItem { [weak self] in
            self?.commitEditorStateNow()
        }
        pendingDraftSave = workItem

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6, execute: workItem)
    }

    func commitEditorStateNow() {
        guard isHistoryTrackingEnabled else { return }

        pendingDraftSave?.cancel()
        pendingDraftSave = nil

        let currentSnapshot = ThumbnailDocumentHistory.snapshot(simpleMakerConfiguration.document)
        if currentSnapshot != historyBaseline {
            history.record(historyBaseline)
            historyBaseline = currentSnapshot
            refreshHistoryAvailability()
        }

        saveDraftNow()
    }

    func undo() {
        commitEditorStateNow()

        let currentSnapshot = ThumbnailDocumentHistory.snapshot(simpleMakerConfiguration.document)
        guard let previous = history.undo(current: currentSnapshot) else {
            refreshHistoryAvailability()
            return
        }

        applyHistoryDocument(previous)
    }

    func redo() {
        let currentSnapshot = ThumbnailDocumentHistory.snapshot(simpleMakerConfiguration.document)
        guard let next = history.redo(current: currentSnapshot) else {
            refreshHistoryAvailability()
            return
        }

        applyHistoryDocument(next)
    }

    private func applyHistoryDocument(_ document: ThumbnailDocument) {
        isApplyingHistory = true
        simpleMakerConfiguration = SimpleMakerConfigurationModel(document: document)
        historyBaseline = ThumbnailDocumentHistory.snapshot(document)
        isApplyingHistory = false
        refreshHistoryAvailability()
        saveDraftNow()
    }

    private func resetHistoryBaseline() {
        history = ThumbnailDocumentHistory()
        historyBaseline = ThumbnailDocumentHistory.snapshot(simpleMakerConfiguration.document)
        refreshHistoryAvailability()
    }

    private func refreshHistoryAvailability() {
        canUndo = history.canUndo
        canRedo = history.canRedo
    }

    private func finishImmediateEditorMutation(previousDocument: ThumbnailDocument) {
        let previousSnapshot = ThumbnailDocumentHistory.snapshot(previousDocument)
        let nextSnapshot = ThumbnailDocumentHistory.snapshot(simpleMakerConfiguration.document)
        defer {
            isApplyingHistory = false
        }

        guard previousSnapshot != nextSnapshot else { return }

        history.record(previousDocument)
        historyBaseline = nextSnapshot
        refreshHistoryAvailability()
        exportReport = nil
        saveDraftNow()
    }

    func applyTemplate(_ template: ThumbnailTemplate) {
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        let previousImage = simpleMakerConfiguration.selectedImage
        let nextDocument = template.makeDocument(preservingImagesFrom: previousDocument)
        var nextConfiguration = SimpleMakerConfigurationModel(document: nextDocument)
        nextConfiguration.selectedImage = previousImage ?? nextConfiguration.selectedImage

        let previousSnapshot = ThumbnailDocumentHistory.snapshot(previousDocument)
        let nextSnapshot = ThumbnailDocumentHistory.snapshot(nextConfiguration.document)
        guard previousSnapshot != nextSnapshot else { return }

        isApplyingHistory = true
        simpleMakerConfiguration = nextConfiguration
        history.record(previousDocument)
        historyBaseline = nextSnapshot
        isApplyingHistory = false
        refreshHistoryAvailability()
        exportReport = nil
        saveDraftNow()
    }

    func apply(idea: ThumbnailIdea) {
        applyTemplate(idea.template)
    }

    func applyBrandKit(_ kit: BrandKit? = nil) {
        guard let kit = kit ?? brandKit else { return }
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        let nextConfiguration = kit.applied(to: simpleMakerConfiguration)
        let previousSnapshot = ThumbnailDocumentHistory.snapshot(previousDocument)
        let nextSnapshot = ThumbnailDocumentHistory.snapshot(nextConfiguration.document)
        guard previousSnapshot != nextSnapshot else { return }

        isApplyingHistory = true
        simpleMakerConfiguration = nextConfiguration
        history.record(previousDocument)
        historyBaseline = nextSnapshot
        isApplyingHistory = false
        refreshHistoryAvailability()
        exportReport = nil
        saveDraftNow()
    }

    func apply(_ suggestion: ThumbnailSuggestion) {
        switch suggestion.action {
        case .shortenText:
            shortenOverlayText()
        case .applyTemplate(let id):
            guard let template = ThumbnailTemplate.builtIns.first(where: { $0.id == id }) else {
                return
            }
            applyTemplate(template)
        case .applyBrandColor:
            applyBrandKit()
        case .cropToDetectedFace, .none:
            return
        }
    }

    func applyAsync(_ suggestion: ThumbnailSuggestion) async {
        switch suggestion.action {
        case .cropToDetectedFace:
            await cropSelectedImageToDetectedFace()
        default:
            apply(suggestion)
        }
    }

    func cropSelectedImageToDetectedFace() async {
        await processSelectedImage(
            failurePrefix: "Failed to crop around faces"
        ) { [subjectProcessor] image in
            guard let crop = try await subjectProcessor.suggestedFaceCrop(in: image, padding: 0.28),
                  let croppedImage = BackgroundRemovalService.croppedImage(
                    image,
                    toNormalizedVisionRect: crop
                  ) else {
                throw BackgroundRemovalError.faceNotDetected
            }

            return croppedImage
        }
    }

    func removeBackgroundFromSelectedImage() async {
        await processSelectedImage(
            failurePrefix: "Failed to remove background"
        ) { [subjectProcessor] image in
            try await subjectProcessor.removeBackground(from: image)
        }
    }

    func removeBackground(from selection: ThumbnailLayerSelection) async {
        if case .content(let layerID) = selection,
           let layer = simpleMakerConfiguration.layers.record(id: layerID),
           case .image(let content) = layer.content,
           let image = UIImage(data: content.imageData) {
            await processImageLayer(
                id: layerID,
                image: image,
                failurePrefix: "Failed to remove background"
            ) { [subjectProcessor] image in
                try await subjectProcessor.removeBackground(from: image)
            }
            return
        }

        await removeBackgroundFromSelectedImage()
    }

    private func isActionableSuggestion(_ suggestion: ThumbnailSuggestion) -> Bool {
        guard suggestion.isCurrentlyActionableInEditor else { return false }

        if case .applyTemplate(let id) = suggestion.action,
           let template = ThumbnailTemplate.builtIns.first(where: { $0.id == id }) {
            let currentDocument = ThumbnailDocumentHistory.snapshot(simpleMakerConfiguration.document)
            let templateConfiguration = SimpleMakerConfigurationModel(
                document: template.makeDocument(preservingImagesFrom: simpleMakerConfiguration.document)
            )
            let templateDocument = ThumbnailDocumentHistory.snapshot(
                templateConfiguration.document
            )
            return currentDocument != templateDocument
        }

        if case .applyBrandColor = suggestion.action {
            guard let brandKit else { return false }
            let currentDocument = ThumbnailDocumentHistory.snapshot(simpleMakerConfiguration.document)
            let brandDocument = ThumbnailDocumentHistory.snapshot(
                brandKit.applied(to: simpleMakerConfiguration).document
            )
            return currentDocument != brandDocument
        }

        return true
    }

    private func shortenOverlayText() {
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        let shortenedText = ThumbnailSuggestionTextShortener.shortened(
            simpleMakerConfiguration.overlayText
        )
        guard shortenedText != simpleMakerConfiguration.overlayText else { return }

        isApplyingHistory = true
        simpleMakerConfiguration.overlayText = shortenedText
        let nextSnapshot = ThumbnailDocumentHistory.snapshot(simpleMakerConfiguration.document)
        history.record(previousDocument)
        historyBaseline = nextSnapshot
        isApplyingHistory = false
        refreshHistoryAvailability()
        exportReport = nil
        saveDraftNow()
    }

    private func processSelectedImage(
        failurePrefix: String,
        operation: @escaping (UIImage) async throws -> UIImage
    ) async {
        guard let image = simpleMakerConfiguration.selectedImage else { return }

        isProcessingSubject = true
        defer {
            isProcessingSubject = false
        }

        do {
            let processedImage = try await operation(image)
            applyProcessedSelectedImage(processedImage)
            saveError = nil
            isPermissionError = false
        } catch {
            isPermissionError = false
            saveError = "\(failurePrefix): \(error.localizedDescription)"
            showingSaveAlert = true
        }
    }

    private func applyProcessedSelectedImage(_ image: UIImage) {
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        let previousSnapshot = ThumbnailDocumentHistory.snapshot(previousDocument)
        isApplyingHistory = true
        simpleMakerConfiguration.selectedImage = image
        let nextSnapshot = ThumbnailDocumentHistory.snapshot(simpleMakerConfiguration.document)
        defer {
            isApplyingHistory = false
        }

        guard previousSnapshot != nextSnapshot else { return }

        history.record(previousDocument)
        historyBaseline = nextSnapshot
        refreshHistoryAvailability()
        exportReport = nil
        saveDraftNow()
    }

    private func processImageLayer(
        id layerID: String,
        image: UIImage,
        failurePrefix: String,
        operation: @escaping (UIImage) async throws -> UIImage
    ) async {
        isProcessingSubject = true
        defer {
            isProcessingSubject = false
        }

        do {
            let processedImage = try await operation(image)
            guard let processedData = processedImage.pngData() else {
                throw BackgroundRemovalError.renderFailed
            }
            applyProcessedImageLayer(id: layerID, imageData: processedData)
            saveError = nil
            isPermissionError = false
        } catch {
            isPermissionError = false
            saveError = "\(failurePrefix): \(error.localizedDescription)"
            showingSaveAlert = true
        }
    }

    private func applyProcessedImageLayer(id layerID: String, imageData: Data) {
        commitEditorStateNow()

        let previousDocument = simpleMakerConfiguration.document
        let previousSnapshot = ThumbnailDocumentHistory.snapshot(previousDocument)
        isApplyingHistory = true
        simpleMakerConfiguration.layers.updateImageContent(id: layerID) { content in
            content.imageData = imageData
        }
        let nextSnapshot = ThumbnailDocumentHistory.snapshot(simpleMakerConfiguration.document)
        defer {
            isApplyingHistory = false
        }

        guard previousSnapshot != nextSnapshot else { return }

        history.record(previousDocument)
        historyBaseline = nextSnapshot
        refreshHistoryAvailability()
        exportReport = nil
        saveDraftNow()
    }
    
    func saveImageWithOverlay(content: some View) async {
        guard hasExportableContent else { return }
        
        await MainActor.run {
            isSaving = true
        }
        
        let exportOptions = simpleMakerConfiguration.exportOptions

        do {
            let renderedImage = try ThumbnailExporter.render(
                content: content,
                options: exportOptions
            )
            let data = try ThumbnailExporter.encodedData(for: renderedImage, options: exportOptions)
            try await ThumbnailExporter.saveEncodedDataToPhotoLibrary(data, options: exportOptions)

            await MainActor.run {
                saveError = nil
                exportReport = ThumbnailExportReport(byteCount: data.count, options: exportOptions)
                successMessage = "Thumbnail saved to Photos"
                showingSaveAlert = true
                isSaving = false
            }
        } catch {
            await MainActor.run {
                isPermissionError = (error as? ThumbnailExportError) == .photoPermissionDenied
                saveError = "Failed to save: \(error.localizedDescription)"
                showingSaveAlert = true
                isSaving = false
            }
        }
    }

    func shareImageWithOverlay(content: some View) async {
        guard hasExportableContent else { return }

        await MainActor.run {
            isPreparingShare = true
        }

        let exportOptions = simpleMakerConfiguration.exportOptions

        do {
            let renderedImage = try ThumbnailExporter.render(
                content: content,
                options: exportOptions
            )
            let data = try ThumbnailExporter.encodedData(for: renderedImage, options: exportOptions)
            let exportURL = try ThumbnailExporter.writeTemporaryExport(
                data: data,
                options: exportOptions,
                baseFileName: exportOptions.preset.id
            )

            await MainActor.run {
                saveError = nil
                exportReport = ThumbnailExportReport(byteCount: data.count, options: exportOptions)
                shareItem = ThumbnailShareItem(url: exportURL)
                isPreparingShare = false
            }
        } catch {
            await MainActor.run {
                isPermissionError = false
                saveError = "Failed to prepare share: \(error.localizedDescription)"
                showingSaveAlert = true
                isPreparingShare = false
            }
        }
    }

    func prepareFileExport(content: some View) async {
        guard hasExportableContent else { return }

        await MainActor.run {
            isPreparingFileExport = true
        }

        let exportOptions = simpleMakerConfiguration.exportOptions

        do {
            let preparedExport = try ThumbnailExporter.preparedFileExport(
                content: content,
                options: exportOptions,
                baseFileName: exportOptions.preset.id
            )

            await MainActor.run {
                saveError = nil
                fileExport = preparedExport
                exportReport = ThumbnailExportReport(
                    byteCount: preparedExport.data.count,
                    options: exportOptions
                )
                isFileExporterPresented = true
                isPreparingFileExport = false
            }
        } catch {
            await MainActor.run {
                isPermissionError = false
                saveError = "Failed to prepare file: \(error.localizedDescription)"
                showingSaveAlert = true
                isPreparingFileExport = false
            }
        }
    }

    func checkExportSize(content: some View) async {
        guard hasExportableContent else { return }

        await MainActor.run {
            isCheckingExportSize = true
        }

        let exportOptions = simpleMakerConfiguration.exportOptions

        do {
            let renderedImage = try ThumbnailExporter.render(
                content: content,
                options: exportOptions
            )
            let data = try ThumbnailExporter.encodedData(for: renderedImage, options: exportOptions)

            await MainActor.run {
                saveError = nil
                exportReport = ThumbnailExportReport(byteCount: data.count, options: exportOptions)
                isCheckingExportSize = false
            }
        } catch {
            await MainActor.run {
                isPermissionError = false
                saveError = "Failed to check export size: \(error.localizedDescription)"
                showingSaveAlert = true
                isCheckingExportSize = false
            }
        }
    }

    func handleFileExportCompletion(_ result: Result<URL, Error>) {
        switch result {
        case .success:
            saveError = nil
            successMessage = "Thumbnail exported to Files"
            showingSaveAlert = true
        case .failure(let error):
            let nsError = error as NSError
            guard nsError.code != NSUserCancelledError else { return }

            isPermissionError = false
            saveError = "File export failed: \(error.localizedDescription)"
            showingSaveAlert = true
        }
    }
    
    func openSettings() {
        if let settingsUrl = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(settingsUrl)
        }
    }

    #if DEBUG
    private static func makeUITestImage() -> UIImage {
        UIGraphicsImageRenderer(size: CGSize(width: 320, height: 180)).image { context in
            UIColor.systemBlue.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 320, height: 180))
            UIColor.systemYellow.setFill()
            context.fill(CGRect(x: 40, y: 40, width: 120, height: 60))
        }
    }

    private static func makeUITestLayerImage() -> UIImage {
        UIGraphicsImageRenderer(size: CGSize(width: 96, height: 64)).image { context in
            UIColor.systemPink.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 96, height: 64))
            UIColor.white.setFill()
            context.cgContext.fillEllipse(in: CGRect(x: 28, y: 12, width: 40, height: 40))
        }
    }
    #endif
}
