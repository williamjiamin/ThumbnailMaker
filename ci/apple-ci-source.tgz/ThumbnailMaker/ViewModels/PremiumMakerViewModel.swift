//
//  PremiumMakerViewModel.swift
//  ThumbnailMaker
//
//  Created by william on 2024/11/28.
//

import PhotosUI
import SwiftUI

@MainActor
class PremiumMakerViewModel: ObservableObject {
    @Published var premiumMakerConfiguration = PremiumMakerConfigurationModel() {
        didSet {
            scheduleDraftAutosave()
        }
    }
    @Published var imageSelection: PhotosPickerItem?
    @Published var layerImageSelection: PhotosPickerItem?
    @Published var stickerImageSelection: PhotosPickerItem?
    @Published var saveError: String?
    @Published var showingSaveAlert = false
    @Published var isSaving = false
    @Published var isPreparingShare = false
    @Published var isPreparingFileExport = false
    @Published var isCheckingExportSize = false
    @Published var isProcessingSubject = false
    @Published var profileImageSelection: PhotosPickerItem?
    @Published var showingProfileCropper = false
    @Published var tempProfileImage: UIImage?
    @Published var isPermissionError = false
    @Published var batchProgress: Double = 0
    @Published var currentBatchNumber: Int = 0
    @Published var isBatchGenerating = false
    @Published var shareItem: ThumbnailShareItem?
    @Published var fileExport: ThumbnailPreparedFileExport?
    @Published var isFileExporterPresented = false
    @Published var exportReport: ThumbnailExportReport?
    @Published var successMessage = "Thumbnail saved to Photos"
    @Published private(set) var brandKit: BrandKit?
    @Published private(set) var restoredDraft = false
    @Published private(set) var canUndo = false
    @Published private(set) var canRedo = false
    private var shouldCancelBatch = false
    @Published var showPhotoPicker = false
    private let draftStore: ThumbnailDraftStore
    private let brandKitStore: BrandKitStore
    private var isDraftPersistenceEnabled = true
    private var pendingDraftSave: DispatchWorkItem?
    private var history = ThumbnailDocumentHistory()
    private var historyBaseline = ThumbnailDocumentHistory.snapshot(PremiumMakerConfigurationModel().document)
    private var isApplyingHistory = false
    private var isHistoryTrackingEnabled = false
    private let suggestionProvider = LocalThumbnailSuggestionProvider()
    private let ideaProvider = LocalThumbnailIdeaProvider()
    private let subjectProcessor: ThumbnailSubjectProcessing
    
    // Add a constant for preview proportion
    let usableHeightProportion: CGFloat = 0.8  
    let previewHeightProportion: CGFloat = 0.35  // Match the simple maker's preview proportion
    let textFieldHeight: CGFloat = 50
    let overlayCharacterLimit = 120

    var actionableSuggestions: [ThumbnailSuggestion] {
        suggestionProvider.suggestions(
            for: premiumMakerConfiguration,
            brandKit: brandKit,
            templates: ThumbnailTemplate.builtIns
        )
        .filter(isActionableSuggestion)
    }

    var titleIdeas: [ThumbnailIdea] {
        ideaProvider.ideas(
            forTitle: premiumMakerConfiguration.overlayText,
            ratio: premiumMakerConfiguration.selectedRatio,
            brandKit: brandKit,
            templates: ThumbnailTemplate.builtIns
        )
    }

    var selectableLayerSelections: [ThumbnailLayerSelection] {
        premiumMakerConfiguration.layers.selectableLayerSelections(
            hasText: !premiumMakerConfiguration.overlayText.isEmpty,
            hasProfile: premiumMakerConfiguration.circularProfile?.image != nil
        )
    }

    var hasExportableContent: Bool {
        premiumMakerConfiguration.selectedImage != nil
            || !premiumMakerConfiguration.overlayText.isEmpty
            || premiumMakerConfiguration.circularProfile?.image != nil
            || premiumMakerConfiguration.layers.hasContentLayers
    }

    func reconcileLayersForCurrentOverlays() {
        let reconciledLayers = premiumMakerConfiguration.layers.reconciledForCurrentOverlays(
            hasText: !premiumMakerConfiguration.overlayText.isEmpty,
            hasProfile: premiumMakerConfiguration.circularProfile?.image != nil
        )

        if reconciledLayers != premiumMakerConfiguration.layers {
            premiumMakerConfiguration.layers = reconciledLayers
        }
    }

    func toggleLayerVisibility(_ selection: ThumbnailLayerSelection) {
        var configuration = premiumMakerConfiguration
        configuration.layers = configuration.layers.reconciledForCurrentOverlays(
            hasText: !configuration.overlayText.isEmpty,
            hasProfile: configuration.circularProfile?.image != nil
        )
        configuration.layers.toggleVisibility(for: selection)
        premiumMakerConfiguration = configuration
    }

    func toggleLayerLock(_ selection: ThumbnailLayerSelection) {
        var configuration = premiumMakerConfiguration
        configuration.layers = configuration.layers.reconciledForCurrentOverlays(
            hasText: !configuration.overlayText.isEmpty,
            hasProfile: configuration.circularProfile?.image != nil
        )
        configuration.layers.toggleLock(for: selection)
        premiumMakerConfiguration = configuration
    }

    func canRemoveBackground(from selection: ThumbnailLayerSelection) -> Bool {
        if case .content(let layerID) = selection,
           let layer = premiumMakerConfiguration.layers.record(id: layerID),
           case .image = layer.content {
            return true
        }

        return premiumMakerConfiguration.selectedImage != nil
    }
    
    init(
        draftStore: ThumbnailDraftStore = ThumbnailDraftStore(kind: .premium),
        brandKitStore: BrandKitStore = BrandKitStore(),
        subjectProcessor: ThumbnailSubjectProcessing = BackgroundRemovalService()
    ) {
        self.draftStore = draftStore
        self.brandKitStore = brandKitStore
        self.subjectProcessor = subjectProcessor

        let launchArguments = ProcessInfo.processInfo.arguments
        if launchArguments.contains("-DisableDraftPersistence") {
            isDraftPersistenceEnabled = false
        }

        if isDraftPersistenceEnabled {
            brandKit = try? brandKitStore.load()
        }

        #if DEBUG
        if launchArguments.contains("-UITestSeedPremiumEditor") {
            isDraftPersistenceEnabled = false
            premiumMakerConfiguration.selectedImage = Self.makeUITestBackgroundImage()
            premiumMakerConfiguration.overlayText = "Layer pick"
            premiumMakerConfiguration.textTransform = ThumbnailOverlayTransform(x: 0.5, y: 0.62)
            premiumMakerConfiguration.circularProfile = CircularProfileConfig(
                image: Self.makeUITestProfileImage(),
                size: 0.2
            )
            premiumMakerConfiguration.profileTransform = ThumbnailOverlayTransform.profileDefault
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }

        if launchArguments.contains("-UITestSeedPremiumTextLayer") {
            isDraftPersistenceEnabled = false
            premiumMakerConfiguration.selectedImage = Self.makeUITestBackgroundImage()
            premiumMakerConfiguration.overlayText = "Premium title"
            premiumMakerConfiguration.layers.addTextLayer(
                value: "Premium Layer",
                id: "ui-test-premium-text-layer",
                color: ThumbnailDocumentColor(red: 1, green: 0.92, blue: 0.18, alpha: 1),
                size: 0.15,
                selectedFontRawValue: CustomFont.montserrat.rawValue,
                transform: ThumbnailOverlayTransform(
                    x: 0.58,
                    y: 0.42,
                    rotationDegrees: 6
                )
            )
            resetHistoryBaseline()
            isHistoryTrackingEnabled = true
            return
        }
        #endif

        if isDraftPersistenceEnabled {
            restoreDraftIfAvailable()
        }

        resetHistoryBaseline()
        isHistoryTrackingEnabled = true
    }
    
    func updateImage() async {
        if let data = try? await imageSelection?.loadTransferable(type: Data.self) {
            // Create a new image instance from data
            if let uiImage = UIImage(data: data) {
                await MainActor.run {
                    premiumMakerConfiguration.selectedImage = uiImage
                }
            }
        }
    }

    func addImageLayerFromSelection() async -> ThumbnailLayerSelection? {
        defer {
            layerImageSelection = nil
        }

        guard let data = try? await layerImageSelection?.loadTransferable(type: Data.self),
              UIImage(data: data) != nil else {
            return nil
        }

        return addImageLayer(imageData: data)
    }

    func addStickerLayerFromSelection() async -> ThumbnailLayerSelection? {
        defer {
            stickerImageSelection = nil
        }

        guard let data = try? await stickerImageSelection?.loadTransferable(type: Data.self),
              UIImage(data: data) != nil else {
            return nil
        }

        return addStickerLayer(imageData: data)
    }

    @discardableResult
    func addImageLayer(imageData: Data) -> ThumbnailLayerSelection {
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        isApplyingHistory = true
        let layerID = premiumMakerConfiguration.layers.addImageLayer(imageData: imageData)
        finishImmediateEditorMutation(previousDocument: previousDocument)
        return .content(layerID)
    }

    @discardableResult
    func addStickerLayer(imageData: Data) -> ThumbnailLayerSelection {
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        isApplyingHistory = true
        let layerID = premiumMakerConfiguration.layers.addStickerLayer(imageData: imageData)
        finishImmediateEditorMutation(previousDocument: previousDocument)
        return .content(layerID)
    }

    @discardableResult
    func addTextLayer(value: String = "New text") -> ThumbnailLayerSelection {
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        isApplyingHistory = true
        let layerID = premiumMakerConfiguration.layers.addTextLayer(
            value: value,
            color: ThumbnailDocumentColor(color: premiumMakerConfiguration.textColor),
            size: Double(premiumMakerConfiguration.textSize),
            selectedFontRawValue: premiumMakerConfiguration.selectedFont.rawValue,
            transform: premiumMakerConfiguration.textTransform
        )
        finishImmediateEditorMutation(previousDocument: previousDocument)
        return .content(layerID)
    }

    @discardableResult
    func addShapeLayer(_ shapeKind: ThumbnailShapeKind) -> ThumbnailLayerSelection {
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        isApplyingHistory = true
        let layerID = premiumMakerConfiguration.layers.addShapeLayer(shapeKind: shapeKind)
        finishImmediateEditorMutation(previousDocument: previousDocument)
        return .content(layerID)
    }

    func duplicateLayer(_ selection: ThumbnailLayerSelection) -> ThumbnailLayerSelection? {
        guard case .content(let layerID) = selection else { return nil }
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        isApplyingHistory = true
        guard let duplicatedLayerID = premiumMakerConfiguration.layers.duplicateContentLayer(id: layerID) else {
            isApplyingHistory = false
            return nil
        }
        finishImmediateEditorMutation(previousDocument: previousDocument)
        return .content(duplicatedLayerID)
    }

    func moveLayerBackward(
        _ selection: ThumbnailLayerSelection,
        within selections: [ThumbnailLayerSelection]
    ) {
        guard premiumMakerConfiguration.layers.canMoveBackward(selection, within: selections) else { return }
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        isApplyingHistory = true
        premiumMakerConfiguration.layers.moveBackward(selection, within: selections)
        finishImmediateEditorMutation(previousDocument: previousDocument)
    }

    func moveLayerForward(
        _ selection: ThumbnailLayerSelection,
        within selections: [ThumbnailLayerSelection]
    ) {
        guard premiumMakerConfiguration.layers.canMoveForward(selection, within: selections) else { return }
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        isApplyingHistory = true
        premiumMakerConfiguration.layers.moveForward(selection, within: selections)
        finishImmediateEditorMutation(previousDocument: previousDocument)
    }

    func deleteLayer(_ selection: ThumbnailLayerSelection) -> ThumbnailLayerSelection? {
        guard case .content(let layerID) = selection else { return nil }
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        isApplyingHistory = true
        premiumMakerConfiguration.layers.deleteContentLayer(id: layerID)
        finishImmediateEditorMutation(previousDocument: previousDocument)
        return selectableLayerSelections.last
    }

    func restoreDraftIfAvailable() {
        do {
            guard let draftConfiguration = try draftStore.loadPremium() else { return }
            premiumMakerConfiguration = draftConfiguration
            restoredDraft = true
            if isHistoryTrackingEnabled {
                resetHistoryBaseline()
            }
        } catch {
            print("Failed to restore Premium Maker draft: \(error.localizedDescription)")
        }
    }

    func saveDraftNow() {
        guard isDraftPersistenceEnabled else { return }

        do {
            try draftStore.save(premiumMakerConfiguration)
        } catch {
            print("Failed to save Premium Maker draft: \(error.localizedDescription)")
        }
    }

    func saveBrandKit(_ kit: BrandKit?) {
        brandKit = kit
        guard isDraftPersistenceEnabled else { return }

        do {
            if let kit {
                try brandKitStore.save(kit)
            } else {
                try brandKitStore.delete()
            }
        } catch {
            saveError = "Failed to save brand kit: \(error.localizedDescription)"
            showingSaveAlert = true
        }
    }

    private func scheduleDraftAutosave() {
        guard isHistoryTrackingEnabled, !isApplyingHistory else { return }

        pendingDraftSave?.cancel()

        let workItem = DispatchWorkItem { [weak self] in
            self?.commitEditorStateNow()
        }
        pendingDraftSave = workItem

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6, execute: workItem)
    }

    func commitEditorStateNow() {
        guard isHistoryTrackingEnabled, !isBatchGenerating else { return }

        pendingDraftSave?.cancel()
        pendingDraftSave = nil

        let currentSnapshot = ThumbnailDocumentHistory.snapshot(premiumMakerConfiguration.document)
        if currentSnapshot != historyBaseline {
            history.record(historyBaseline)
            historyBaseline = currentSnapshot
            refreshHistoryAvailability()
        }

        saveDraftNow()
    }

    func undo() {
        commitEditorStateNow()

        let currentSnapshot = ThumbnailDocumentHistory.snapshot(premiumMakerConfiguration.document)
        guard let previous = history.undo(current: currentSnapshot) else {
            refreshHistoryAvailability()
            return
        }

        applyHistoryDocument(previous)
    }

    func redo() {
        let currentSnapshot = ThumbnailDocumentHistory.snapshot(premiumMakerConfiguration.document)
        guard let next = history.redo(current: currentSnapshot) else {
            refreshHistoryAvailability()
            return
        }

        applyHistoryDocument(next)
    }

    private func applyHistoryDocument(_ document: ThumbnailDocument) {
        isApplyingHistory = true
        premiumMakerConfiguration = PremiumMakerConfigurationModel(document: document)
        historyBaseline = ThumbnailDocumentHistory.snapshot(document)
        isApplyingHistory = false
        refreshHistoryAvailability()
        saveDraftNow()
    }

    private func resetHistoryBaseline() {
        history = ThumbnailDocumentHistory()
        historyBaseline = ThumbnailDocumentHistory.snapshot(premiumMakerConfiguration.document)
        refreshHistoryAvailability()
    }

    private func refreshHistoryAvailability() {
        canUndo = history.canUndo
        canRedo = history.canRedo
    }

    private func finishImmediateEditorMutation(previousDocument: ThumbnailDocument) {
        let previousSnapshot = ThumbnailDocumentHistory.snapshot(previousDocument)
        let nextSnapshot = ThumbnailDocumentHistory.snapshot(premiumMakerConfiguration.document)
        defer {
            isApplyingHistory = false
        }

        guard previousSnapshot != nextSnapshot else { return }

        history.record(previousDocument)
        historyBaseline = nextSnapshot
        refreshHistoryAvailability()
        exportReport = nil
        saveDraftNow()
    }

    func applyTemplate(_ template: ThumbnailTemplate) {
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        let previousImage = premiumMakerConfiguration.selectedImage
        let previousProfileImage = premiumMakerConfiguration.circularProfile?.image
        let nextDocument = template.makeDocument(preservingImagesFrom: previousDocument)
        var nextConfiguration = PremiumMakerConfigurationModel(document: nextDocument)
        nextConfiguration.selectedImage = previousImage ?? nextConfiguration.selectedImage
        if let previousProfileImage, nextConfiguration.circularProfile != nil {
            nextConfiguration.circularProfile?.image = previousProfileImage
        }

        let previousSnapshot = ThumbnailDocumentHistory.snapshot(previousDocument)
        let nextSnapshot = ThumbnailDocumentHistory.snapshot(nextConfiguration.document)
        guard previousSnapshot != nextSnapshot else { return }

        isApplyingHistory = true
        premiumMakerConfiguration = nextConfiguration
        history.record(previousDocument)
        historyBaseline = nextSnapshot
        isApplyingHistory = false
        refreshHistoryAvailability()
        exportReport = nil
        saveDraftNow()
    }

    func apply(idea: ThumbnailIdea) {
        applyTemplate(idea.template)
    }

    func applyBrandKit(_ kit: BrandKit? = nil) {
        guard let kit = kit ?? brandKit else { return }
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        let nextConfiguration = kit.applied(to: premiumMakerConfiguration)
        let previousSnapshot = ThumbnailDocumentHistory.snapshot(previousDocument)
        let nextSnapshot = ThumbnailDocumentHistory.snapshot(nextConfiguration.document)
        guard previousSnapshot != nextSnapshot else { return }

        isApplyingHistory = true
        premiumMakerConfiguration = nextConfiguration
        history.record(previousDocument)
        historyBaseline = nextSnapshot
        isApplyingHistory = false
        refreshHistoryAvailability()
        exportReport = nil
        saveDraftNow()
    }

    func apply(_ suggestion: ThumbnailSuggestion) {
        switch suggestion.action {
        case .shortenText:
            shortenOverlayText()
        case .applyTemplate(let id):
            guard let template = ThumbnailTemplate.builtIns.first(where: { $0.id == id }) else {
                return
            }
            applyTemplate(template)
        case .applyBrandColor:
            applyBrandKit()
        case .cropToDetectedFace, .none:
            return
        }
    }

    func applyAsync(_ suggestion: ThumbnailSuggestion) async {
        switch suggestion.action {
        case .cropToDetectedFace:
            await cropSelectedImageToDetectedFace()
        default:
            apply(suggestion)
        }
    }

    func cropSelectedImageToDetectedFace() async {
        await processSelectedImage(
            failurePrefix: "Failed to crop around faces"
        ) { [subjectProcessor] image in
            guard let crop = try await subjectProcessor.suggestedFaceCrop(in: image, padding: 0.28),
                  let croppedImage = BackgroundRemovalService.croppedImage(
                    image,
                    toNormalizedVisionRect: crop
                  ) else {
                throw BackgroundRemovalError.faceNotDetected
            }

            return croppedImage
        }
    }

    func removeBackgroundFromSelectedImage() async {
        await processSelectedImage(
            failurePrefix: "Failed to remove background"
        ) { [subjectProcessor] image in
            try await subjectProcessor.removeBackground(from: image)
        }
    }

    func removeBackground(from selection: ThumbnailLayerSelection) async {
        if case .content(let layerID) = selection,
           let layer = premiumMakerConfiguration.layers.record(id: layerID),
           case .image(let content) = layer.content,
           let image = UIImage(data: content.imageData) {
            await processImageLayer(
                id: layerID,
                image: image,
                failurePrefix: "Failed to remove background"
            ) { [subjectProcessor] image in
                try await subjectProcessor.removeBackground(from: image)
            }
            return
        }

        await removeBackgroundFromSelectedImage()
    }

    private func isActionableSuggestion(_ suggestion: ThumbnailSuggestion) -> Bool {
        guard suggestion.isCurrentlyActionableInEditor else { return false }

        if case .applyTemplate(let id) = suggestion.action,
           let template = ThumbnailTemplate.builtIns.first(where: { $0.id == id }) {
            let currentDocument = ThumbnailDocumentHistory.snapshot(premiumMakerConfiguration.document)
            let templateConfiguration = PremiumMakerConfigurationModel(
                document: template.makeDocument(preservingImagesFrom: premiumMakerConfiguration.document)
            )
            let templateDocument = ThumbnailDocumentHistory.snapshot(
                templateConfiguration.document
            )
            return currentDocument != templateDocument
        }

        if case .applyBrandColor = suggestion.action {
            guard let brandKit else { return false }
            let currentDocument = ThumbnailDocumentHistory.snapshot(premiumMakerConfiguration.document)
            let brandDocument = ThumbnailDocumentHistory.snapshot(
                brandKit.applied(to: premiumMakerConfiguration).document
            )
            return currentDocument != brandDocument
        }

        return true
    }

    private func shortenOverlayText() {
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        let shortenedText = ThumbnailSuggestionTextShortener.shortened(
            premiumMakerConfiguration.overlayText
        )
        guard shortenedText != premiumMakerConfiguration.overlayText else { return }

        isApplyingHistory = true
        premiumMakerConfiguration.overlayText = shortenedText
        let nextSnapshot = ThumbnailDocumentHistory.snapshot(premiumMakerConfiguration.document)
        history.record(previousDocument)
        historyBaseline = nextSnapshot
        isApplyingHistory = false
        refreshHistoryAvailability()
        exportReport = nil
        saveDraftNow()
    }

    private func processSelectedImage(
        failurePrefix: String,
        operation: @escaping (UIImage) async throws -> UIImage
    ) async {
        guard let image = premiumMakerConfiguration.selectedImage else { return }

        isProcessingSubject = true
        defer {
            isProcessingSubject = false
        }

        do {
            let processedImage = try await operation(image)
            applyProcessedSelectedImage(processedImage)
            saveError = nil
            isPermissionError = false
        } catch {
            isPermissionError = false
            saveError = "\(failurePrefix): \(error.localizedDescription)"
            showingSaveAlert = true
        }
    }

    private func applyProcessedSelectedImage(_ image: UIImage) {
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        let previousSnapshot = ThumbnailDocumentHistory.snapshot(previousDocument)
        isApplyingHistory = true
        premiumMakerConfiguration.selectedImage = image
        let nextSnapshot = ThumbnailDocumentHistory.snapshot(premiumMakerConfiguration.document)
        defer {
            isApplyingHistory = false
        }

        guard previousSnapshot != nextSnapshot else { return }

        history.record(previousDocument)
        historyBaseline = nextSnapshot
        refreshHistoryAvailability()
        exportReport = nil
        saveDraftNow()
    }

    private func processImageLayer(
        id layerID: String,
        image: UIImage,
        failurePrefix: String,
        operation: @escaping (UIImage) async throws -> UIImage
    ) async {
        isProcessingSubject = true
        defer {
            isProcessingSubject = false
        }

        do {
            let processedImage = try await operation(image)
            guard let processedData = processedImage.pngData() else {
                throw BackgroundRemovalError.renderFailed
            }
            applyProcessedImageLayer(id: layerID, imageData: processedData)
            saveError = nil
            isPermissionError = false
        } catch {
            isPermissionError = false
            saveError = "\(failurePrefix): \(error.localizedDescription)"
            showingSaveAlert = true
        }
    }

    private func applyProcessedImageLayer(id layerID: String, imageData: Data) {
        commitEditorStateNow()

        let previousDocument = premiumMakerConfiguration.document
        let previousSnapshot = ThumbnailDocumentHistory.snapshot(previousDocument)
        isApplyingHistory = true
        premiumMakerConfiguration.layers.updateImageContent(id: layerID) { content in
            content.imageData = imageData
        }
        let nextSnapshot = ThumbnailDocumentHistory.snapshot(premiumMakerConfiguration.document)
        defer {
            isApplyingHistory = false
        }

        guard previousSnapshot != nextSnapshot else { return }

        history.record(previousDocument)
        historyBaseline = nextSnapshot
        refreshHistoryAvailability()
        exportReport = nil
        saveDraftNow()
    }
    
    func saveImageWithOverlay(content: some View, showSuccessAlert: Bool = true) async {
        guard hasExportableContent else { return }
        
        await MainActor.run {
            isSaving = true
        }

        let exportOptions = premiumMakerConfiguration.exportOptions

        do {
            let renderedImage = try ThumbnailExporter.render(
                content: content,
                options: exportOptions
            )
            let data = try ThumbnailExporter.encodedData(for: renderedImage, options: exportOptions)
            try await ThumbnailExporter.saveEncodedDataToPhotoLibrary(data, options: exportOptions)

            if PurchaseManager.shared.purchasedProductIDs.isEmpty {
                PurchaseManager.shared.useFreeTrial()
            }

            await MainActor.run {
                saveError = nil
                exportReport = ThumbnailExportReport(byteCount: data.count, options: exportOptions)
                successMessage = "Thumbnail saved to Photos"
                showingSaveAlert = showSuccessAlert
                isSaving = false
                imageSelection = nil
                profileImageSelection = nil
            }
        } catch {
            await MainActor.run {
                isPermissionError = (error as? ThumbnailExportError) == .photoPermissionDenied
                saveError = "Save failed: \(error.localizedDescription)"
                showingSaveAlert = true
                isSaving = false
            }
        }
    }

    func shareImageWithOverlay(content: some View) async {
        guard hasExportableContent else { return }

        await MainActor.run {
            isPreparingShare = true
        }

        let exportOptions = premiumMakerConfiguration.exportOptions

        do {
            let renderedImage = try ThumbnailExporter.render(
                content: content,
                options: exportOptions
            )
            let data = try ThumbnailExporter.encodedData(for: renderedImage, options: exportOptions)
            let exportURL = try ThumbnailExporter.writeTemporaryExport(
                data: data,
                options: exportOptions,
                baseFileName: exportOptions.preset.id
            )

            await MainActor.run {
                saveError = nil
                exportReport = ThumbnailExportReport(byteCount: data.count, options: exportOptions)
                shareItem = ThumbnailShareItem(url: exportURL)
                isPreparingShare = false
            }
        } catch {
            await MainActor.run {
                isPermissionError = false
                saveError = "Failed to prepare share: \(error.localizedDescription)"
                showingSaveAlert = true
                isPreparingShare = false
            }
        }
    }

    func prepareFileExport(content: some View) async {
        guard hasExportableContent else { return }

        await MainActor.run {
            isPreparingFileExport = true
        }

        let exportOptions = premiumMakerConfiguration.exportOptions

        do {
            let preparedExport = try ThumbnailExporter.preparedFileExport(
                content: content,
                options: exportOptions,
                baseFileName: exportOptions.preset.id
            )

            await MainActor.run {
                saveError = nil
                fileExport = preparedExport
                exportReport = ThumbnailExportReport(
                    byteCount: preparedExport.data.count,
                    options: exportOptions
                )
                isFileExporterPresented = true
                isPreparingFileExport = false
            }
        } catch {
            await MainActor.run {
                isPermissionError = false
                saveError = "Failed to prepare file: \(error.localizedDescription)"
                showingSaveAlert = true
                isPreparingFileExport = false
            }
        }
    }

    func checkExportSize(content: some View) async {
        guard hasExportableContent else { return }

        await MainActor.run {
            isCheckingExportSize = true
        }

        let exportOptions = premiumMakerConfiguration.exportOptions

        do {
            let renderedImage = try ThumbnailExporter.render(
                content: content,
                options: exportOptions
            )
            let data = try ThumbnailExporter.encodedData(for: renderedImage, options: exportOptions)

            await MainActor.run {
                saveError = nil
                exportReport = ThumbnailExportReport(byteCount: data.count, options: exportOptions)
                isCheckingExportSize = false
            }
        } catch {
            await MainActor.run {
                isPermissionError = false
                saveError = "Failed to check export size: \(error.localizedDescription)"
                showingSaveAlert = true
                isCheckingExportSize = false
            }
        }
    }

    func handleFileExportCompletion(_ result: Result<URL, Error>) {
        switch result {
        case .success:
            saveError = nil
            successMessage = "Thumbnail exported to Files"
            showingSaveAlert = true
        case .failure(let error):
            let nsError = error as NSError
            guard nsError.code != NSUserCancelledError else { return }

            isPermissionError = false
            saveError = "File export failed: \(error.localizedDescription)"
            showingSaveAlert = true
        }
    }
    
    func updateProfileImage() async {
        if let data = try? await profileImageSelection?.loadTransferable(type: Data.self) {
            // Create a separate image instance from data
            if let uiImage = UIImage(data: data) {
                await MainActor.run {
                    tempProfileImage = uiImage
                    showingProfileCropper = true
                }
            }
        }
    }
    
    func setProfileImage(_ image: UIImage) {
        if premiumMakerConfiguration.circularProfile == nil {
            premiumMakerConfiguration.circularProfile = CircularProfileConfig(
                image: image,
                size: 0.2
            )
        } else {
            premiumMakerConfiguration.circularProfile?.image = image
        }
    }
    
    func openSettings() {
        if let settingsUrl = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(settingsUrl)
        }
    }
    
    func cancelBatchGeneration() {
        shouldCancelBatch = true
    }

    #if DEBUG
    private static func makeUITestBackgroundImage() -> UIImage {
        UIGraphicsImageRenderer(size: CGSize(width: 320, height: 180)).image { context in
            UIColor.systemBlue.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 320, height: 180))
            UIColor.systemYellow.setFill()
            context.fill(CGRect(x: 48, y: 42, width: 128, height: 64))
        }
    }

    private static func makeUITestProfileImage() -> UIImage {
        UIGraphicsImageRenderer(size: CGSize(width: 96, height: 96)).image { context in
            UIColor.systemCyan.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 96, height: 96))
            UIColor.systemPurple.setFill()
            context.fill(CGRect(x: 24, y: 24, width: 48, height: 48))
        }
    }
    #endif
    
    func generateBatchImages(content: @escaping (String) -> some View) async {
        guard premiumMakerConfiguration.macroConfig.isEnabled,
              premiumMakerConfiguration.macroConfig.isValid else { return }
        
        let start = premiumMakerConfiguration.macroConfig.startNumber
        let end = premiumMakerConfiguration.macroConfig.endNumber
        let baseText = premiumMakerConfiguration.overlayText
        let totalCount = premiumMakerConfiguration.macroConfig.totalCount
        shouldCancelBatch = false
        
        await MainActor.run {
            isSaving = true
            isBatchGenerating = true
            batchProgress = 0
            currentBatchNumber = 0
        }
        defer {
            isBatchGenerating = false
        }
        
        let range: any Sequence<Int> = start < end ? start...end : stride(from: start, through: end, by: -1)
        
        for number in range {
            if shouldCancelBatch {
                break
            }
            
            let text = premiumMakerConfiguration.macroConfig.appendPosition == .after ?
                "\(baseText) \(number)" : "\(number) \(baseText)"
            
            await MainActor.run {
                premiumMakerConfiguration.overlayText = text
                currentBatchNumber += 1
                batchProgress = Double(currentBatchNumber) / Double(totalCount)
            }
            
            await saveImageWithOverlay(content: content(text), showSuccessAlert: false)
            
            try? await Task.sleep(nanoseconds: 500_000_000)
        }
        
        await MainActor.run {
            premiumMakerConfiguration.overlayText = baseText
            isSaving = false
            batchProgress = 0
            currentBatchNumber = 0
            saveError = nil
            showingSaveAlert = true
        }
    }
}
