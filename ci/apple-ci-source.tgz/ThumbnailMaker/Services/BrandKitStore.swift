//
//  BrandKitStore.swift
//  ThumbnailMaker
//

import Foundation

final class BrandKitStore {
    let fileURL: URL

    init(fileURL: URL = BrandKitStore.defaultFileURL) {
        self.fileURL = fileURL
    }

    static var defaultFileURL: URL {
        let applicationSupport = FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first ?? FileManager.default.temporaryDirectory

        return applicationSupport
            .appendingPathComponent("ThumbnailMaker", isDirectory: true)
            .appendingPathComponent("BrandKits", isDirectory: true)
            .appendingPathComponent("brand-kit.json")
    }

    func save(_ brandKit: BrandKit) throws {
        var brandKit = brandKit
        brandKit.updatedAt = Date()

        try FileManager.default.createDirectory(
            at: fileURL.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )

        try JSONEncoder.brandKitEncoder
            .encode(brandKit)
            .write(to: fileURL, options: [.atomic])
    }

    func load() throws -> BrandKit? {
        guard FileManager.default.fileExists(atPath: fileURL.path) else {
            return nil
        }

        let data = try Data(contentsOf: fileURL)
        return try JSONDecoder.brandKitDecoder.decode(BrandKit.self, from: data)
    }

    func delete() throws {
        guard FileManager.default.fileExists(atPath: fileURL.path) else {
            return
        }

        try FileManager.default.removeItem(at: fileURL)
    }
}

private extension JSONEncoder {
    static var brandKitEncoder: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }
}

private extension JSONDecoder {
    static var brandKitDecoder: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}
