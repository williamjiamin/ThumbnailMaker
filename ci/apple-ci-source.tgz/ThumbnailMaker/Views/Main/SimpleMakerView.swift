//
//  SimpleMakerView.swift
//  ThumbnailMaker
//
//  Created by william on 2024/11/28.
//

import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

struct SimpleMakerView: View {
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @StateObject private var viewModel = SimpleMakerViewModel()
    @StateObject private var purchaseManager = PurchaseManager.shared
    @FocusState private var isFocused: Bool
    @State private var isSettingsPresented: Bool = false
    @State private var isTemplateGalleryPresented: Bool = false
    @State private var isBrandKitEditorPresented: Bool = false
    @State private var showsSafeZoneGuide = true
    @State private var selectedLayer: ThumbnailLayerSelection = .textOverlay
    @Namespace private var bottomID
    @Namespace private var topID
    
    var body: some View {
        NavigationStack {
            GeometryReader { geometry in
                makerContent(in: geometry)
                .scrollDismissesKeyboard(.immediately)
                .simultaneousGesture(
                    TapGesture().onEnded { _ in
                        isFocused = false
                    }
                )
            }
            .navigationTitle("Simple Maker")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        isSettingsPresented.toggle()
                    }) {
                        Image(systemName: "gearshape")
                    }
                    .accessibilityIdentifier("settingsButton")
                    .accessibilityLabel("Settings")
                }
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button {
                        isFocused = false
                        isTemplateGalleryPresented = true
                    } label: {
                        Image(systemName: "square.grid.2x2")
                    }
                    .accessibilityIdentifier("templatesButton")
                    .accessibilityLabel("Templates")

                    UndoRedoToolbarButtons(
                        canUndo: viewModel.canUndo,
                        canRedo: viewModel.canRedo,
                        undo: {
                            isFocused = false
                            viewModel.undo()
                        },
                        redo: {
                            isFocused = false
                            viewModel.redo()
                        }
                    )
                }
            }
        }
        .alert(isPresented: $viewModel.showingSaveAlert) {
            if let error = viewModel.saveError {
                Alert(
                    title: Text("Save Failed"),
                    message: Text(error),
                    primaryButton: viewModel.isPermissionError ? 
                        .default(Text("Open Settings"), action: {
                            viewModel.openSettings()
                        }) : .default(Text("OK")),
                    secondaryButton: .cancel(Text("Cancel"))
                )
            } else {
                Alert(
                    title: Text("Success"),
                    message: Text(viewModel.successMessage),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
        .sheet(isPresented: $isSettingsPresented) {
            SettingsView()
        }
        .sheet(isPresented: $isTemplateGalleryPresented) {
            TemplateGalleryView { template in
                isFocused = false
                viewModel.applyTemplate(template)
                selectTextLayerIfAvailable()
                isTemplateGalleryPresented = false
            }
        }
        .sheet(isPresented: $isBrandKitEditorPresented) {
            BrandKitEditorView(
                brandKit: viewModel.brandKit,
                allowsPremiumFonts: purchaseManager.canAccessPremium,
                saveBrandKit: { kit in
                    viewModel.saveBrandKit(kit)
                },
                applyBrandKit: { kit in
                    viewModel.saveBrandKit(kit)
                    viewModel.applyBrandKit(kit)
                }
            )
        }
        .sheet(item: $viewModel.shareItem) { item in
            ShareSheet(activityItems: [item.url])
        }
        .fileExporter(
            isPresented: $viewModel.isFileExporterPresented,
            document: ThumbnailFileDocument(data: viewModel.fileExport?.data ?? Data()),
            contentType: viewModel.fileExport?.contentType ?? .png,
            defaultFilename: viewModel.fileExport?.fileName ?? "thumbnailmaker-export.png"
        ) { result in
            viewModel.handleFileExportCompletion(result)
        }
        .onChange(of: viewModel.imageSelection) { oldValue, newValue in
            if newValue != nil {
                Task {
                    await viewModel.updateImage()
                }
            }
        }
        .onChange(of: viewModel.layerImageSelection) { oldValue, newValue in
            if newValue != nil {
                Task {
                    if let layerSelection = await viewModel.addImageLayerFromSelection() {
                        selectedLayer = layerSelection
                    }
                }
            }
        }
        .onChange(of: viewModel.stickerImageSelection) { oldValue, newValue in
            if newValue != nil {
                Task {
                    if let layerSelection = await viewModel.addStickerLayerFromSelection() {
                        selectedLayer = layerSelection
                    }
                }
            }
        }
        .onChange(of: viewModel.simpleMakerConfiguration.overlayText) { oldValue, newValue in
            viewModel.reconcileLayersForCurrentOverlays()
            normalizeSelectedLayer()
        }
        .onChange(of: viewModel.simpleMakerConfiguration.layers) { oldValue, newValue in
            normalizeSelectedLayer()
        }
    }

    @ViewBuilder
    private func makerContent(in geometry: GeometryProxy) -> some View {
        if usesRegularEditorLayout(in: geometry) {
            regularEditorLayout(in: geometry)
        } else {
            compactEditorLayout(in: geometry)
        }
    }

    private func usesRegularEditorLayout(in geometry: GeometryProxy) -> Bool {
        horizontalSizeClass == .regular
            && geometry.size.width >= 820
            && !dynamicTypeSize.isAccessibilitySize
    }

    private func compactEditorLayout(in geometry: GeometryProxy) -> some View {
        let availableWidth = max(1, geometry.size.width - 40)
        let availableHeight = max(1, geometry.size.height * viewModel.usableHeightProportion)
        let previewHeight = max(1, availableHeight * viewModel.previewHeightProportion)
        let previewWidth = max(1, previewHeight * viewModel.simpleMakerConfiguration.selectedRatio.value)

        return ScrollView {
            VStack(spacing: 20) {
                previewSection(
                    width: previewWidth,
                    height: previewHeight,
                    maxWidth: availableWidth
                )
                textInputSection
                layerStripSection
                coreControlsSection
                smallPreviewSection
                actionButtonsSection
            }
        }
        .accessibilityIdentifier("simpleCompactEditorLayout")
    }

    private func regularEditorLayout(in geometry: GeometryProxy) -> some View {
        let rightPaneWidth = min(420, max(320, geometry.size.width * 0.34))
        let leftPaneWidth = max(360, geometry.size.width - rightPaneWidth)
        let canvasHeightByWidth = max(
            1,
            (leftPaneWidth - 40) / viewModel.simpleMakerConfiguration.selectedRatio.value
        )
        let maxCanvasHeight = max(1, geometry.size.height * 0.78)
        let previewHeight = min(canvasHeightByWidth, maxCanvasHeight)
        let previewWidth = previewHeight * viewModel.simpleMakerConfiguration.selectedRatio.value

        return HStack(spacing: 0) {
            ScrollView {
                VStack(spacing: 20) {
                    previewSection(
                        width: previewWidth,
                        height: previewHeight,
                        maxWidth: leftPaneWidth - 40
                    )
                    smallPreviewSection
                }
                .padding(.vertical, 20)
                .frame(maxWidth: .infinity, alignment: .top)
            }
            .frame(width: leftPaneWidth)
            .background(Color(uiColor: .systemBackground))

            Divider()

            ScrollView {
                VStack(spacing: 20) {
                    textInputSection
                    layerStripSection
                    coreControlsSection
                    actionButtonsSection
                }
                .padding(.vertical, 20)
                .frame(maxWidth: .infinity, alignment: .top)
            }
            .frame(width: rightPaneWidth)
            .background(Color(uiColor: .secondarySystemBackground).opacity(0.35))
        }
        .accessibilityIdentifier("simpleRegularEditorLayout")
    }

    private func previewSection(width: CGFloat, height: CGFloat, maxWidth: CGFloat) -> some View {
        PreviewComponentView(
            simpleMakerConfiguration: $viewModel.simpleMakerConfiguration,
            width: width,
            height: height,
            isTextInteractive: true,
            safeZone: activeSafeZone,
            selectedOverlay: $selectedLayer
        )
        .frame(maxWidth: maxWidth, maxHeight: height)
        .padding(.horizontal, 20)
    }

    private var textInputSection: some View {
        OverlayTextEditor(
            text: $viewModel.simpleMakerConfiguration.overlayText,
            placeholder: "Add overlay text",
            characterLimit: viewModel.overlayCharacterLimit,
            focus: $isFocused
        )
        .padding(.horizontal, 20)
    }

    private var layerStripSection: some View {
        LayerSelectionStripView(
            selection: $selectedLayer,
            layerRecords: $viewModel.simpleMakerConfiguration.layers,
            layers: editableLayers,
            moveLayerBackward: { layer, layers in
                viewModel.moveLayerBackward(layer, within: layers)
            },
            moveLayerForward: { layer, layers in
                viewModel.moveLayerForward(layer, within: layers)
            },
            toggleLayerVisibility: { layer in
                viewModel.toggleLayerVisibility(layer)
            },
            toggleLayerLock: { layer in
                viewModel.toggleLayerLock(layer)
            },
            duplicateLayer: { layer in
                if let duplicatedLayer = viewModel.duplicateLayer(layer) {
                    selectedLayer = duplicatedLayer
                }
            },
            deleteLayer: { layer in
                selectedLayer = viewModel.deleteLayer(layer) ?? .textOverlay
                normalizeSelectedLayer()
            }
        )
        .padding(.horizontal, 20)
    }

    private var smallPreviewSection: some View {
        ThumbnailSmallPreviewPanel(
            aspectRatio: viewModel.simpleMakerConfiguration.selectedRatio,
            isVisible: viewModel.hasExportableContent,
            accessibilitySummary: smallPreviewAccessibilitySummary
        ) { size in
            PreviewComponentView(
                simpleMakerConfiguration: $viewModel.simpleMakerConfiguration,
                width: size.width,
                height: size.height
            )
        }
        .padding(.horizontal, 20)
    }

    private var smallPreviewAccessibilitySummary: String? {
        let text = viewModel.simpleMakerConfiguration.overlayText
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return text.isEmpty ? nil : "Visible title text: \(text)"
    }

    private var coreControlsSection: some View {
        VStack(spacing: 16) {
            if let selectedTextLayerContent {
                TextLayerContentControlView(
                    content: selectedTextLayerContent,
                    characterLimit: viewModel.overlayCharacterLimit,
                    isPremium: purchaseManager.canAccessPremium
                )
                .padding(.horizontal, 20)

                CustomizationControlComponentView(
                    configuration: $viewModel.simpleMakerConfiguration,
                    showsSafeZoneGuide: $showsSafeZoneGuide,
                    isPremium: purchaseManager.canAccessPremium
                )
                .padding(.horizontal, 20)
            } else {
                CustomizationControlComponentView(
                    configuration: $viewModel.simpleMakerConfiguration,
                    showsSafeZoneGuide: $showsSafeZoneGuide,
                    isPremium: purchaseManager.canAccessPremium
                )
                .padding(.horizontal, 20)

                TextControlView(
                    textColor: $viewModel.simpleMakerConfiguration.textColor,
                    textTransform: $viewModel.simpleMakerConfiguration.textTransform,
                    selectedFont: $viewModel.simpleMakerConfiguration.selectedFont,
                    usesFallbackFont: $viewModel.simpleMakerConfiguration.usesFallbackFont,
                    previewText: $viewModel.simpleMakerConfiguration.overlayText,
                    isPremium: purchaseManager.canAccessPremium
                )
                .padding(.horizontal, 20)
            }
        }
    }

    private var selectedTextLayerContent: Binding<ThumbnailTextLayerContent>? {
        guard case .content(let layerID) = selectedLayer,
              let layer = viewModel.simpleMakerConfiguration.layers.record(id: layerID),
              case .text(let currentContent) = layer.content else {
            return nil
        }

        return Binding(
            get: {
                guard let layer = viewModel.simpleMakerConfiguration.layers.record(id: layerID),
                      case .text(let content) = layer.content else {
                    return currentContent
                }
                return content
            },
            set: { nextContent in
                viewModel.simpleMakerConfiguration.layers.updateTextContent(id: layerID) { content in
                    content = nextContent
                }
            }
        )
    }

    private var actionButtonsSection: some View {
        VStack(spacing: 12) {
            LazyVGrid(
                columns: [GridItem(.adaptive(minimum: 58), spacing: 12)],
                spacing: 12
            ) {
                PhotosPicker(selection: $viewModel.imageSelection, matching: .images) {
                    CreatorActionIcon(
                        systemName: "photo",
                        colors: [.blue, .blue.opacity(0.8)]
                    )
                }
                .accessibilityLabel("Select Image")

                Button {
                    isFocused = false
                    isBrandKitEditorPresented = true
                } label: {
                    CreatorActionIcon(
                        systemName: "paintpalette",
                        colors: [.purple, .pink.opacity(0.82)]
                    )
                }
                .accessibilityIdentifier("brandKitButton")
                .accessibilityLabel("Brand Kit")

                PhotosPicker(selection: $viewModel.layerImageSelection, matching: .images) {
                    CreatorActionIcon(
                        systemName: "photo.on.rectangle",
                        colors: [.mint, .mint.opacity(0.8)]
                    )
                }
                .accessibilityIdentifier("addImageLayerButton")
                .accessibilityLabel("Add Image Layer")

                PhotosPicker(selection: $viewModel.stickerImageSelection, matching: .images) {
                    CreatorActionIcon(
                        systemName: "face.smiling",
                        colors: [.teal, .green.opacity(0.82)]
                    )
                    .accessibilityIdentifier("addStickerLayerButton")
                }
                .accessibilityIdentifier("addStickerLayerButton")
                .accessibilityLabel("Add Sticker Layer")

                Button {
                    isFocused = false
                    selectedLayer = viewModel.addTextLayer()
                } label: {
                    CreatorActionIcon(
                        systemName: "textformat",
                        colors: [.indigo, .cyan.opacity(0.82)]
                    )
                }
                .accessibilityIdentifier("addTextLayerButton")
                .accessibilityLabel("Add Text Layer")

                Menu {
                    Button {
                        selectedLayer = viewModel.addShapeLayer(.rectangle)
                    } label: {
                        Label("Rectangle", systemImage: "rectangle")
                    }

                    Button {
                        selectedLayer = viewModel.addShapeLayer(.ellipse)
                    } label: {
                        Label("Ellipse", systemImage: "oval")
                    }
                } label: {
                    CreatorActionIcon(
                        systemName: "square.on.circle",
                        colors: [.orange, .orange.opacity(0.82)]
                    )
                }
                .accessibilityIdentifier("addShapeLayerButton")
                .accessibilityLabel("Add Shape Layer")

                if viewModel.canRemoveBackground(from: selectedLayer) {
                    Button {
                        isFocused = false
                        Task {
                            await viewModel.removeBackground(from: selectedLayer)
                        }
                    } label: {
                        CreatorActionIcon(
                            systemName: "person.crop.rectangle",
                            colors: [.pink, .pink.opacity(0.82)],
                            isLoading: viewModel.isProcessingSubject
                        )
                    }
                    .accessibilityIdentifier("removeBackgroundButton")
                    .accessibilityLabel("Remove Background")
                    .accessibilityValue(viewModel.isProcessingSubject ? "Busy" : "")
                    .disabled(viewModel.isProcessingSubject)
                }

                if viewModel.hasExportableContent {
                    Button(action: saveImage) {
                        CreatorActionIcon(
                            systemName: "square.and.arrow.down",
                            colors: [.green, .green.opacity(0.8)],
                            isLoading: viewModel.isSaving
                        )
                    }
                    .accessibilityLabel("Save to Photos")
                    .accessibilityValue(viewModel.isSaving ? "Busy" : "")
                    .disabled(viewModel.isSaving || viewModel.isPreparingShare || viewModel.isPreparingFileExport)

                    Button(action: shareImage) {
                        CreatorActionIcon(
                            systemName: "square.and.arrow.up",
                            colors: [.indigo, .indigo.opacity(0.8)],
                            isLoading: viewModel.isPreparingShare
                        )
                    }
                    .accessibilityLabel("Share Export")
                    .accessibilityValue(viewModel.isPreparingShare ? "Busy" : "")
                    .disabled(viewModel.isSaving || viewModel.isPreparingShare || viewModel.isPreparingFileExport)

                    Button(action: prepareFileExport) {
                        CreatorActionIcon(
                            systemName: "folder",
                            colors: [.teal, .teal.opacity(0.8)],
                            isLoading: viewModel.isPreparingFileExport
                        )
                    }
                    .accessibilityLabel("Export to Files")
                    .accessibilityValue(viewModel.isPreparingFileExport ? "Busy" : "")
                    .disabled(viewModel.isSaving || viewModel.isPreparingShare || viewModel.isPreparingFileExport)
                }
            }

            TitleIdeasStripView(
                ideas: viewModel.titleIdeas,
                applyIdea: { idea in
                    isFocused = false
                    viewModel.apply(idea: idea)
                    selectTextLayerIfAvailable()
                }
            )

            ExportReadinessPanel(
                report: viewModel.exportReport,
                readinessReport: ThumbnailReadinessAnalyzer.analyze(
                    viewModel.simpleMakerConfiguration
                ),
                isChecking: viewModel.isCheckingExportSize,
                canCheckSize: viewModel.hasExportableContent,
                suggestions: viewModel.actionableSuggestions,
                applySuggestion: { suggestion in
                    isFocused = false
                    Task {
                        await viewModel.applyAsync(suggestion)
                        selectTextLayerIfAvailable()
                    }
                }
            ) {
                checkExportSize()
            }
        }
        .padding(.vertical, 16)
        .padding(.horizontal, 20)
    }

    private func saveImage() {
        isFocused = false
        let targetSize = viewModel.simpleMakerConfiguration.exportOptions.outputSize.cgSize
        let content = PreviewComponentView(
            simpleMakerConfiguration: $viewModel.simpleMakerConfiguration,
            width: targetSize.width,
            height: targetSize.height
        )
        Task {
            await viewModel.saveImageWithOverlay(content: content)
        }
    }

    private func shareImage() {
        isFocused = false
        let targetSize = viewModel.simpleMakerConfiguration.exportOptions.outputSize.cgSize
        let content = PreviewComponentView(
            simpleMakerConfiguration: $viewModel.simpleMakerConfiguration,
            width: targetSize.width,
            height: targetSize.height
        )
        Task {
            await viewModel.shareImageWithOverlay(content: content)
        }
    }

    private func prepareFileExport() {
        isFocused = false
        let targetSize = viewModel.simpleMakerConfiguration.exportOptions.outputSize.cgSize
        let content = PreviewComponentView(
            simpleMakerConfiguration: $viewModel.simpleMakerConfiguration,
            width: targetSize.width,
            height: targetSize.height
        )
        Task {
            await viewModel.prepareFileExport(content: content)
        }
    }

    private func checkExportSize() {
        isFocused = false
        let targetSize = viewModel.simpleMakerConfiguration.exportOptions.outputSize.cgSize
        let content = PreviewComponentView(
            simpleMakerConfiguration: $viewModel.simpleMakerConfiguration,
            width: targetSize.width,
            height: targetSize.height
        )
        Task {
            await viewModel.checkExportSize(content: content)
        }
    }

    private var activeSafeZone: ThumbnailSafeZone? {
        showsSafeZoneGuide ? viewModel.simpleMakerConfiguration.exportOptions.activeSafeZone : nil
    }

    private var editableLayers: [ThumbnailLayerSelection] {
        viewModel.selectableLayerSelections
    }

    private func selectTextLayerIfAvailable() {
        if editableLayers.contains(.textOverlay) {
            selectedLayer = .textOverlay
        } else {
            normalizeSelectedLayer()
        }
    }

    private func normalizeSelectedLayer() {
        let layers = editableLayers
        if layers.contains(selectedLayer) {
            return
        }

        if let firstLayer = layers.first {
            selectedLayer = firstLayer
        }
    }
    
    private func premiumFeatureTeaser(icon: String, text: String) -> some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.system(size: 24))
                .foregroundStyle(.linearGradient(colors: [.blue, .purple],
                                               startPoint: .topLeading,
                                               endPoint: .bottomTrailing))
            Text(text)
                .font(.caption)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .contentShape(Rectangle())
        .onTapGesture {
            NotificationCenter.default.post(
                name: Notification.Name("ShowPremiumUpgrade"),
                object: nil
            )
        }
    }
}

#Preview {
    SimpleMakerView()
}
