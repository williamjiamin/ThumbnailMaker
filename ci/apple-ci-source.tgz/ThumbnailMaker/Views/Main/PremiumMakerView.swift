//
//  PremiumMakerView.swift
//  ThumbnailMaker
//
//  Created by william on 2024/11/28.
//

import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

struct PremiumMakerView: View {
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @StateObject private var viewModel = PremiumMakerViewModel()
    @StateObject private var purchaseManager = PurchaseManager.shared
    @FocusState private var focusedField: TextFieldFocus?
    @State private var isSettingsPresented: Bool = false
    @State private var showingPurchaseMessage = false
    @State private var purchaseMessage: String?
    @Namespace private var bottomID
    @Namespace private var topID
    @State private var showingPurchaseAlert = false
    @State private var showingToast = false
    @State private var toastMessage = ""
    @State private var showingMacroSettings = false
    @State private var showingYouTubeInput = false
    @State private var showingQuotaLimit = false
    @State private var isTemplateGalleryPresented = false
    @State private var isBrandKitEditorPresented = false
    @State private var showsSafeZoneGuide = true
    @State private var timerRefreshTrigger = Date()
    @State private var selectedLayer: ThumbnailLayerSelection = .textOverlay
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        Group {
            if purchaseManager.canAccessPremium {
                premiumContent
            } else {
                purchasePromptView
            }
        }
    }
    
    private var purchasePromptView: some View {
        VStack {
            ScrollView {
                VStack(spacing: 32) {
                    // Premium Header
                    VStack(spacing: 12) {
                        Image(systemName: "star.circle.fill")
                            .font(.system(size: 60))
                            .foregroundStyle(.linearGradient(colors: [.blue, .purple], 
                                                           startPoint: .topLeading, 
                                                           endPoint: .bottomTrailing))
                        
                        Text("Premium Maker")
                            .font(.title)
                            .bold()
                        
                        Text("Create Professional Thumbnails")
                            .font(.title3)
                            .foregroundColor(.secondary)
                    }
                    .padding(.top, 60)
                    
                    // Feature List
                    VStack(alignment: .leading, spacing: 16) {
                        premiumFeatureRow(icon: "photo.circle", text: "Profile Image Overlay")
                        premiumFeatureRow(icon: "rectangle.stack", text: "Batch Generation")
                        premiumFeatureRow(icon: "slider.horizontal.3", text: "Advanced Controls")
                        premiumFeatureRow(icon: "square.and.arrow.down", text: "Unlimited Exports")
                    }
                    .padding(.horizontal, 32)
                    
                    Spacer()
                        .frame(height: 20)
                }
            }
            
            // Purchase and Restore Buttons in a footer
            VStack(spacing: 16) {
                if let product = purchaseManager.products.first {
                    Button(action: {
                        Task {
                            try? await purchaseManager.purchase()
                        }
                    }) {
                        Text("Upgrade to Premium (\(product.displayPrice))")
                            .bold()
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(
                                LinearGradient(colors: [.blue, .purple],
                                             startPoint: .leading,
                                             endPoint: .trailing)
                            )
                            .cornerRadius(16)
                    }
                }
                
                Button(action: {
                    Task {
                        await purchaseManager.restorePurchases()
                    }
                }) {
                    HStack {
                        if purchaseManager.isRestoringPurchases {
                            ProgressView()
                                .tint(.blue)
                        } else {
                            Text("Already purchased? Restore")
                                .font(.subheadline)
                        }
                    }
                    .foregroundColor(.blue)
                    .padding(.vertical, 12)
                }
                .disabled(purchaseManager.isRestoringPurchases)
            }
            .padding(.horizontal, 32)
            .padding(.bottom, 32)
            .background(
                Color(uiColor: .systemBackground)
                    .shadow(color: .black.opacity(0.05), radius: 8, y: -4)
            )
        }
        .alert("Purchase Status", isPresented: $showingPurchaseMessage, presenting: purchaseMessage) { message in
            Button("OK", role: .cancel) { }
        } message: { message in
            Text(message)
        }
        .onReceive(NotificationCenter.default.publisher(for: NSNotification.Name("ShowPurchaseMessage"))) { notification in
            if let message = notification.userInfo?["message"] as? String {
                purchaseMessage = message
                showingPurchaseMessage = true
            }
        }
    }
    
    private var premiumContent: some View {
        NavigationStack {
            GeometryReader { geometry in
                makerContent(in: geometry)
            }
            .onTapGesture {
                focusedField = nil
                UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), 
                                              to: nil, 
                                              from: nil, 
                                              for: nil)
            }
            .ignoresSafeArea(.keyboard)
            .navigationTitle("Premium")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        isSettingsPresented.toggle()
                    }) {
                        Image(systemName: "gearshape")
                    }
                    .accessibilityIdentifier("settingsButton")
                    .accessibilityLabel("Settings")
                }
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button {
                        focusedField = nil
                        isTemplateGalleryPresented = true
                    } label: {
                        Image(systemName: "square.grid.2x2")
                    }
                    .accessibilityIdentifier("templatesButton")
                    .accessibilityLabel("Templates")

                    UndoRedoToolbarButtons(
                        canUndo: viewModel.canUndo,
                        canRedo: viewModel.canRedo,
                        undo: {
                            focusedField = nil
                            viewModel.undo()
                        },
                        redo: {
                            focusedField = nil
                            viewModel.redo()
                        }
                    )
                }
            }
        }
        .overlay(alignment: .bottom) {
            if showingToast {
                ToastView(message: toastMessage)
            }
        }
        .alert(isPresented: $viewModel.showingSaveAlert) {
            if let error = viewModel.saveError {
                Alert(
                    title: Text("Save Failed"),
                    message: Text(error),
                    primaryButton: viewModel.isPermissionError ? 
                        .default(Text("Open Settings"), action: {
                            viewModel.openSettings()
                        }) : .default(Text("OK")),
                    secondaryButton: .cancel(Text("Cancel"))
                )
            } else {
                Alert(
                    title: Text("Success"),
                    message: Text(viewModel.successMessage),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
        .sheet(isPresented: $isSettingsPresented) {
            SettingsView()
        }
        .sheet(isPresented: $isTemplateGalleryPresented) {
            TemplateGalleryView { template in
                focusedField = nil
                viewModel.applyTemplate(template)
                normalizeSelectedLayer()
                isTemplateGalleryPresented = false
            }
        }
        .sheet(isPresented: $isBrandKitEditorPresented) {
            BrandKitEditorView(
                brandKit: viewModel.brandKit,
                allowsPremiumFonts: purchaseManager.canAccessPremium,
                saveBrandKit: { kit in
                    viewModel.saveBrandKit(kit)
                },
                applyBrandKit: { kit in
                    viewModel.saveBrandKit(kit)
                    viewModel.applyBrandKit(kit)
                }
            )
        }
        .sheet(isPresented: $viewModel.showingProfileCropper) {
            if let image = viewModel.tempProfileImage {
                CircularImageCropperView(
                    isPresented: $viewModel.showingProfileCropper,
                    originalImage: image
                ) { croppedImage in
                    viewModel.setProfileImage(croppedImage)
                }
            }
        }
        .sheet(isPresented: $showingYouTubeInput) {
            // On dismiss
            focusedField = nil
        } content: {
            YouTubeURLInputView { image, title in
                viewModel.premiumMakerConfiguration.selectedImage = image
                if !title.isEmpty {
                    viewModel.premiumMakerConfiguration.overlayText = title
                }
                focusedField = nil
            }
        }
        .sheet(isPresented: $showingQuotaLimit) {
            QuotaLimitView()
        }
        .sheet(item: $viewModel.shareItem) { item in
            ShareSheet(activityItems: [item.url])
        }
        .fileExporter(
            isPresented: $viewModel.isFileExporterPresented,
            document: ThumbnailFileDocument(data: viewModel.fileExport?.data ?? Data()),
            contentType: viewModel.fileExport?.contentType ?? .png,
            defaultFilename: viewModel.fileExport?.fileName ?? "thumbnailmaker-export.png"
        ) { result in
            viewModel.handleFileExportCompletion(result)
        }
        .onChange(of: viewModel.imageSelection) { oldValue, newValue in
            Task {
                await viewModel.updateImage()
            }
        }
        .onChange(of: viewModel.layerImageSelection) { oldValue, newValue in
            if newValue != nil {
                Task {
                    if let layerSelection = await viewModel.addImageLayerFromSelection() {
                        selectedLayer = layerSelection
                    }
                }
            }
        }
        .onChange(of: viewModel.stickerImageSelection) { oldValue, newValue in
            if newValue != nil {
                Task {
                    if let layerSelection = await viewModel.addStickerLayerFromSelection() {
                        selectedLayer = layerSelection
                    }
                }
            }
        }
        .onChange(of: viewModel.profileImageSelection) { oldValue, newValue in
            if newValue != nil {
                Task {
                    await viewModel.updateProfileImage()
                }
            }
        }
        .overlay {
            if viewModel.isBatchGenerating {
                Color.black.opacity(0.5)
                    .ignoresSafeArea()
                
                BatchProgressView(
                    progress: viewModel.batchProgress,
                    currentNumber: viewModel.currentBatchNumber,
                    totalCount: viewModel.premiumMakerConfiguration.macroConfig.totalCount,
                    onCancel: {
                        viewModel.cancelBatchGeneration()
                    }
                )
            }
        }
        .fullScreenCover(isPresented: $showingMacroSettings) {
            MacroSettingsView(
                macroConfig: $viewModel.premiumMakerConfiguration.macroConfig,
                hasSelectedImage: viewModel.premiumMakerConfiguration.selectedImage != nil,
                baseText: viewModel.premiumMakerConfiguration.overlayText
            )
        }
        .onChange(of: viewModel.premiumMakerConfiguration.overlayText) { oldValue, newValue in
            viewModel.reconcileLayersForCurrentOverlays()
            normalizeSelectedLayer()
        }
        .onChange(of: viewModel.premiumMakerConfiguration.circularProfile?.image != nil) { oldValue, newValue in
            viewModel.reconcileLayersForCurrentOverlays()
            normalizeSelectedLayer()
        }
        .onChange(of: viewModel.premiumMakerConfiguration.layers) { oldValue, newValue in
            normalizeSelectedLayer()
        }
    }

    @ViewBuilder
    private func makerContent(in geometry: GeometryProxy) -> some View {
        if usesRegularEditorLayout(in: geometry) {
            regularEditorLayout(in: geometry)
        } else {
            compactEditorLayout(in: geometry)
        }
    }

    private func usesRegularEditorLayout(in geometry: GeometryProxy) -> Bool {
        horizontalSizeClass == .regular
            && geometry.size.width >= 820
            && !dynamicTypeSize.isAccessibilitySize
    }

    private func compactEditorLayout(in geometry: GeometryProxy) -> some View {
        let availableWidth = max(1, geometry.size.width - 40)
        let availableHeight = max(1, geometry.size.height * viewModel.usableHeightProportion)
        let previewHeight = max(1, availableHeight * viewModel.previewHeightProportion)
        let previewWidth = max(1, previewHeight * viewModel.premiumMakerConfiguration.selectedRatio.value)

        return ScrollView {
            VStack(spacing: 0) {
                previewSection(
                    width: previewWidth,
                    height: previewHeight,
                    maxWidth: availableWidth
                )
                textInputSection
                layerStripSection
                coreControlsSection
                smallPreviewSection
                actionButtonsSection
                batchSettingsSection
            }
        }
        .frame(maxWidth: .infinity, alignment: .top)
        .accessibilityIdentifier("premiumCompactEditorLayout")
    }

    private func regularEditorLayout(in geometry: GeometryProxy) -> some View {
        let rightPaneWidth = min(420, max(320, geometry.size.width * 0.34))
        let leftPaneWidth = max(360, geometry.size.width - rightPaneWidth)
        let canvasHeightByWidth = max(
            1,
            (leftPaneWidth - 40) / viewModel.premiumMakerConfiguration.selectedRatio.value
        )
        let maxCanvasHeight = max(1, geometry.size.height * 0.78)
        let previewHeight = min(canvasHeightByWidth, maxCanvasHeight)
        let previewWidth = previewHeight * viewModel.premiumMakerConfiguration.selectedRatio.value

        return HStack(spacing: 0) {
            ScrollView {
                VStack(spacing: 20) {
                    previewSection(
                        width: previewWidth,
                        height: previewHeight,
                        maxWidth: leftPaneWidth - 40
                    )
                    smallPreviewSection
                }
                .padding(.vertical, 20)
                .frame(maxWidth: .infinity, alignment: .top)
            }
            .frame(width: leftPaneWidth)
            .background(Color(uiColor: .systemBackground))

            Divider()

            ScrollView {
                VStack(spacing: 20) {
                    textInputSection
                    layerStripSection
                    coreControlsSection
                    regularActionButtonsSection
                    batchSettingsSection
                }
                .padding(.vertical, 20)
                .frame(maxWidth: .infinity, alignment: .top)
            }
            .frame(width: rightPaneWidth)
            .background(Color(uiColor: .secondarySystemBackground).opacity(0.35))
        }
        .accessibilityIdentifier("premiumRegularEditorLayout")
    }

    private func previewSection(width: CGFloat, height: CGFloat, maxWidth: CGFloat) -> some View {
        PremiumPreviewComponentView(
            premiumMakerConfiguration: $viewModel.premiumMakerConfiguration,
            width: width,
            height: height,
            isInteractive: true,
            safeZone: activeSafeZone,
            selectedOverlay: $selectedLayer,
            fallbackStateDidChange: { usesFallback in
                if viewModel.premiumMakerConfiguration.usesFallbackFont != usesFallback {
                    viewModel.premiumMakerConfiguration.usesFallbackFont = usesFallback
                }
            }
        )
        .frame(maxWidth: maxWidth, maxHeight: height)
        .padding(.horizontal, 20)
    }

    private var textInputSection: some View {
        ZStack(alignment: .topLeading) {
            TextEditor(text: $viewModel.premiumMakerConfiguration.overlayText)
                .font(.body)
                .focused($focusedField, equals: .overlayText)
                .padding(.horizontal, 12)
                .padding(.vertical, 14)
                .frame(minHeight: 96, idealHeight: 112, maxHeight: 180)
                .scrollContentBackground(.hidden)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color(uiColor: .systemGray6))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(
                                    LinearGradient(
                                        colors: [.blue.opacity(0.3), .purple.opacity(0.3)],
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    )
                                )
                        )
                )
                .accessibilityLabel("Overlay text")

            if viewModel.premiumMakerConfiguration.overlayText.isEmpty {
                Text("Enter overlay text")
                    .foregroundStyle(Color.accessibleSecondaryText)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 18)
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)
            }
        }
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()

                    Button("Done") {
                        focusedField = nil
                    }
                    .accessibilityIdentifier("premiumOverlayTextKeyboardDoneButton")
                    .accessibilityLabel("Done editing overlay text")
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
    }

    private var layerStripSection: some View {
        LayerSelectionStripView(
            selection: $selectedLayer,
            layerRecords: $viewModel.premiumMakerConfiguration.layers,
            layers: editableLayers,
            moveLayerBackward: { layer, layers in
                viewModel.moveLayerBackward(layer, within: layers)
            },
            moveLayerForward: { layer, layers in
                viewModel.moveLayerForward(layer, within: layers)
            },
            toggleLayerVisibility: { layer in
                viewModel.toggleLayerVisibility(layer)
            },
            toggleLayerLock: { layer in
                viewModel.toggleLayerLock(layer)
            },
            duplicateLayer: { layer in
                if let duplicatedLayer = viewModel.duplicateLayer(layer) {
                    selectedLayer = duplicatedLayer
                }
            },
            deleteLayer: { layer in
                selectedLayer = viewModel.deleteLayer(layer) ?? .textOverlay
                normalizeSelectedLayer()
            }
        )
        .padding(.horizontal, 20)
        .padding(.top, 12)
    }

    private var smallPreviewSection: some View {
        ThumbnailSmallPreviewPanel(
            aspectRatio: viewModel.premiumMakerConfiguration.selectedRatio,
            isVisible: viewModel.hasExportableContent,
            accessibilitySummary: smallPreviewAccessibilitySummary
        ) { size in
            PremiumPreviewComponentView(
                premiumMakerConfiguration: viewModel.premiumMakerConfiguration,
                width: size.width,
                height: size.height
            )
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
    }

    private var smallPreviewAccessibilitySummary: String? {
        let text = viewModel.premiumMakerConfiguration.overlayText
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return text.isEmpty ? nil : "Visible title text: \(text)"
    }

    private var coreControlsSection: some View {
        VStack(spacing: 16) {
            if let selectedTextLayerContent {
                TextLayerContentControlView(
                    content: selectedTextLayerContent,
                    characterLimit: viewModel.overlayCharacterLimit,
                    isPremium: true
                )
                .padding(.horizontal, 20)

                PremiumCustomizationControlComponentView(
                    configuration: $viewModel.premiumMakerConfiguration,
                    showsSafeZoneGuide: $showsSafeZoneGuide
                )
                .padding(.horizontal, 20)
            } else {
                PremiumCustomizationControlComponentView(
                    configuration: $viewModel.premiumMakerConfiguration,
                    showsSafeZoneGuide: $showsSafeZoneGuide
                )
                .padding(.horizontal, 20)

                PremiumTextControlView(
                    selectedLayer: $selectedLayer,
                    textTransform: $viewModel.premiumMakerConfiguration.textTransform,
                    profileTransform: $viewModel.premiumMakerConfiguration.profileTransform,
                    textColor: $viewModel.premiumMakerConfiguration.textColor,
                    selectedFont: $viewModel.premiumMakerConfiguration.selectedFont,
                    usesFallbackFont: $viewModel.premiumMakerConfiguration.usesFallbackFont,
                    previewText: $viewModel.premiumMakerConfiguration.overlayText
                )
                .padding(.horizontal, 20)
            }
        }
    }

    private var selectedTextLayerContent: Binding<ThumbnailTextLayerContent>? {
        guard case .content(let layerID) = selectedLayer,
              let layer = viewModel.premiumMakerConfiguration.layers.record(id: layerID),
              case .text(let currentContent) = layer.content else {
            return nil
        }

        return Binding(
            get: {
                guard let layer = viewModel.premiumMakerConfiguration.layers.record(id: layerID),
                      case .text(let content) = layer.content else {
                    return currentContent
                }
                return content
            },
            set: { nextContent in
                viewModel.premiumMakerConfiguration.layers.updateTextContent(id: layerID) { content in
                    content = nextContent
                }
            }
        )
    }

    private var activeSafeZone: ThumbnailSafeZone? {
        showsSafeZoneGuide ? viewModel.premiumMakerConfiguration.exportOptions.activeSafeZone : nil
    }

    private var editableLayers: [ThumbnailLayerSelection] {
        viewModel.selectableLayerSelections
    }

    private func normalizeSelectedLayer() {
        let layers = editableLayers
        guard !layers.contains(selectedLayer), let firstLayer = layers.first else { return }
        selectedLayer = firstLayer
    }
    
    private var actionButtonsSection: some View {
        VStack(spacing: 16) {
            // Primary actions row - Select Image and YouTube Import
            LazyVGrid(
                columns: [GridItem(.adaptive(minimum: 150), spacing: 12)],
                spacing: 12
            ) {
                // Select Image button (library only)
                PhotosPicker(selection: $viewModel.imageSelection,
                           matching: .images) {
                    HStack {
                        Image(systemName: "photo")
                        Text("Select Image")
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .background(
                        LinearGradient(colors: [.blue, .blue.opacity(0.8)],
                                     startPoint: .leading,
                                     endPoint: .trailing)
                    )
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }

                PhotosPicker(selection: $viewModel.layerImageSelection,
                           matching: .images) {
                    HStack {
                        Image(systemName: "photo.on.rectangle")
                        Text("Image Layer")
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .background(
                        LinearGradient(colors: [.mint, .mint.opacity(0.8)],
                                     startPoint: .leading,
                                     endPoint: .trailing)
                    )
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
                .accessibilityIdentifier("addImageLayerButton")
                .accessibilityLabel("Add Image Layer")

                PhotosPicker(selection: $viewModel.stickerImageSelection,
                           matching: .images) {
                    HStack {
                        Image(systemName: "face.smiling")
                        Text("Sticker")
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .background(
                        LinearGradient(
                            colors: [.teal, .green.opacity(0.82)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .accessibilityIdentifier("addStickerLayerButton")
                }
                .accessibilityIdentifier("addStickerLayerButton")
                .accessibilityLabel("Add Sticker Layer")

                Button {
                    focusedField = nil
                    selectedLayer = viewModel.addTextLayer()
                } label: {
                    HStack {
                        Image(systemName: "textformat")
                        Text("Text Layer")
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .background(
                        LinearGradient(
                            colors: [.indigo, .cyan.opacity(0.82)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
                .accessibilityIdentifier("addTextLayerButton")
                .accessibilityLabel("Add Text Layer")

                Button {
                    focusedField = nil
                    isBrandKitEditorPresented = true
                } label: {
                    HStack {
                        Image(systemName: "paintpalette")
                        Text("Brand Kit")
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .background(
                        LinearGradient(
                            colors: [.purple, .pink.opacity(0.82)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
                .accessibilityIdentifier("brandKitButton")
                .accessibilityLabel("Brand Kit")

                Menu {
                    Button {
                        selectedLayer = viewModel.addShapeLayer(.rectangle)
                    } label: {
                        Label("Rectangle", systemImage: "rectangle")
                    }

                    Button {
                        selectedLayer = viewModel.addShapeLayer(.ellipse)
                    } label: {
                        Label("Ellipse", systemImage: "oval")
                    }
                } label: {
                    HStack {
                        Image(systemName: "square.on.circle")
                        Text("Shape")
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .background(
                        LinearGradient(colors: [.orange, .orange.opacity(0.82)],
                                     startPoint: .leading,
                                     endPoint: .trailing)
                    )
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
                .accessibilityIdentifier("addShapeLayerButton")
                .accessibilityLabel("Add Shape Layer")

                if viewModel.canRemoveBackground(from: selectedLayer) {
                    Button {
                        focusedField = nil
                        Task {
                            await viewModel.removeBackground(from: selectedLayer)
                        }
                    } label: {
                        HStack {
                            if viewModel.isProcessingSubject {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Image(systemName: "person.crop.rectangle")
                            }
                            Text(viewModel.isProcessingSubject ? "Cutting Out" : "Cutout")
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .frame(maxWidth: .infinity, minHeight: 44)
                        .background(
                            LinearGradient(
                                colors: [.pink, .pink.opacity(0.82)],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .accessibilityIdentifier("removeBackgroundButton")
                    .accessibilityLabel("Remove Background")
                    .accessibilityValue(viewModel.isProcessingSubject ? "Busy" : "")
                    .disabled(viewModel.isProcessingSubject)
                }
                
                // YouTube Import button
                Button(action: {
                    focusedField = nil
                    
                    // Check quota before showing YouTube input
                    let importStatus = PurchaseManager.shared.youtubeImportsRemaining
                    if importStatus <= 0 {
                        showingQuotaLimit = true
                    } else {
                        showingYouTubeInput = true
                    }
                }) {
                    HStack {
                        Image(systemName: "play.rectangle.fill")
                        Text("YouTube Import")
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .background(
                        LinearGradient(colors: [.purple, .purple.opacity(0.8)],
                                     startPoint: .leading,
                                     endPoint: .trailing)
                    )
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
            }
            
            // Secondary actions row - Profile and export
            if viewModel.hasExportableContent {
                LazyVGrid(
                    columns: [GridItem(.adaptive(minimum: 58), spacing: 12)],
                    spacing: 12
                ) {
                    // Profile Image button
                    PhotosPicker(selection: $viewModel.profileImageSelection,
                               matching: .images) {
                        CreatorActionIcon(
                            systemName: "person.crop.circle",
                            colors: [.orange, .orange.opacity(0.8)]
                        )
                    }
                    .accessibilityLabel("Add Profile Image")
                    
                    // Save button
                    Button(action: {
                        focusedField = nil
                        let targetSize = viewModel.premiumMakerConfiguration.exportOptions.outputSize.cgSize
                        let content = PremiumPreviewComponentView(
                            premiumMakerConfiguration: viewModel.premiumMakerConfiguration,
                            width: targetSize.width,
                            height: targetSize.height
                        )
                        Task {
                            await viewModel.saveImageWithOverlay(content: content)
                        }
                    }) {
                        CreatorActionIcon(
                            systemName: "square.and.arrow.down",
                            colors: [.green, .green.opacity(0.8)],
                            isLoading: viewModel.isSaving
                        )
                    }
                    .accessibilityLabel("Save to Photos")
                    .accessibilityValue(viewModel.isSaving ? "Busy" : "")
                    .disabled(viewModel.isSaving || viewModel.isPreparingShare || viewModel.isPreparingFileExport)

                    // Share button
                    Button(action: {
                        focusedField = nil
                        let targetSize = viewModel.premiumMakerConfiguration.exportOptions.outputSize.cgSize
                        let content = PremiumPreviewComponentView(
                            premiumMakerConfiguration: viewModel.premiumMakerConfiguration,
                            width: targetSize.width,
                            height: targetSize.height
                        )
                        Task {
                            await viewModel.shareImageWithOverlay(content: content)
                        }
                    }) {
                        CreatorActionIcon(
                            systemName: "square.and.arrow.up",
                            colors: [.indigo, .indigo.opacity(0.8)],
                            isLoading: viewModel.isPreparingShare
                        )
                    }
                    .accessibilityLabel("Share Export")
                    .accessibilityValue(viewModel.isPreparingShare ? "Busy" : "")
                    .disabled(viewModel.isSaving || viewModel.isPreparingShare || viewModel.isPreparingFileExport)

                    // Files button
                    Button(action: {
                        focusedField = nil
                        let targetSize = viewModel.premiumMakerConfiguration.exportOptions.outputSize.cgSize
                        let content = PremiumPreviewComponentView(
                            premiumMakerConfiguration: viewModel.premiumMakerConfiguration,
                            width: targetSize.width,
                            height: targetSize.height
                        )
                        Task {
                            await viewModel.prepareFileExport(content: content)
                        }
                    }) {
                        CreatorActionIcon(
                            systemName: "folder",
                            colors: [.teal, .teal.opacity(0.8)],
                            isLoading: viewModel.isPreparingFileExport
                        )
                    }
                    .accessibilityLabel("Export to Files")
                    .accessibilityValue(viewModel.isPreparingFileExport ? "Busy" : "")
                    .disabled(viewModel.isSaving || viewModel.isPreparingShare || viewModel.isPreparingFileExport)
                }

                TitleIdeasStripView(
                    ideas: viewModel.titleIdeas,
                    applyIdea: { idea in
                        focusedField = nil
                        viewModel.apply(idea: idea)
                        normalizeSelectedLayer()
                    }
                )

                ExportReadinessPanel(
                    report: viewModel.exportReport,
                    readinessReport: ThumbnailReadinessAnalyzer.analyze(
                        viewModel.premiumMakerConfiguration
                    ),
                    isChecking: viewModel.isCheckingExportSize,
                    canCheckSize: viewModel.hasExportableContent,
                    suggestions: viewModel.actionableSuggestions,
                    applySuggestion: { suggestion in
                        focusedField = nil
                        Task {
                            await viewModel.applyAsync(suggestion)
                            normalizeSelectedLayer()
                        }
                    }
                ) {
                    focusedField = nil
                    let targetSize = viewModel.premiumMakerConfiguration.exportOptions.outputSize.cgSize
                    let content = PremiumPreviewComponentView(
                        premiumMakerConfiguration: viewModel.premiumMakerConfiguration,
                        width: targetSize.width,
                        height: targetSize.height
                    )
                    Task {
                        await viewModel.checkExportSize(content: content)
                    }
                }
            }
        }
        .padding(.vertical, 16)
        .padding(.horizontal, 20)
    }

    private var regularActionButtonsSection: some View {
        VStack(spacing: 16) {
            LazyVGrid(
                columns: [GridItem(.adaptive(minimum: 58), spacing: 12)],
                spacing: 12
            ) {
                PhotosPicker(selection: $viewModel.imageSelection, matching: .images) {
                    CreatorActionIcon(
                        systemName: "photo",
                        colors: [.blue, .blue.opacity(0.8)]
                    )
                }
                .accessibilityLabel("Select Image")

                PhotosPicker(selection: $viewModel.layerImageSelection, matching: .images) {
                    CreatorActionIcon(
                        systemName: "photo.on.rectangle",
                        colors: [.mint, .mint.opacity(0.8)]
                    )
                }
                .accessibilityIdentifier("addImageLayerButton")
                .accessibilityLabel("Add Image Layer")

                PhotosPicker(selection: $viewModel.stickerImageSelection, matching: .images) {
                    CreatorActionIcon(
                        systemName: "face.smiling",
                        colors: [.teal, .green.opacity(0.82)]
                    )
                }
                .accessibilityIdentifier("addStickerLayerButton")
                .accessibilityLabel("Add Sticker Layer")

                Button {
                    focusedField = nil
                    selectedLayer = viewModel.addTextLayer()
                } label: {
                    CreatorActionIcon(
                        systemName: "textformat",
                        colors: [.indigo, .cyan.opacity(0.82)]
                    )
                }
                .accessibilityIdentifier("addTextLayerButton")
                .accessibilityLabel("Add Text Layer")

                Button {
                    focusedField = nil
                    isBrandKitEditorPresented = true
                } label: {
                    CreatorActionIcon(
                        systemName: "paintpalette",
                        colors: [.purple, .pink.opacity(0.82)]
                    )
                }
                .accessibilityIdentifier("brandKitButton")
                .accessibilityLabel("Brand Kit")

                Menu {
                    Button {
                        selectedLayer = viewModel.addShapeLayer(.rectangle)
                    } label: {
                        Label("Rectangle", systemImage: "rectangle")
                    }

                    Button {
                        selectedLayer = viewModel.addShapeLayer(.ellipse)
                    } label: {
                        Label("Ellipse", systemImage: "oval")
                    }
                } label: {
                    CreatorActionIcon(
                        systemName: "square.on.circle",
                        colors: [.orange, .orange.opacity(0.82)]
                    )
                }
                .accessibilityIdentifier("addShapeLayerButton")
                .accessibilityLabel("Add Shape Layer")

                if viewModel.canRemoveBackground(from: selectedLayer) {
                    Button {
                        focusedField = nil
                        Task {
                            await viewModel.removeBackground(from: selectedLayer)
                        }
                    } label: {
                        CreatorActionIcon(
                            systemName: "person.crop.rectangle",
                            colors: [.pink, .pink.opacity(0.82)],
                            isLoading: viewModel.isProcessingSubject
                        )
                    }
                    .accessibilityIdentifier("removeBackgroundButton")
                    .accessibilityLabel("Remove Background")
                    .accessibilityValue(viewModel.isProcessingSubject ? "Busy" : "")
                    .disabled(viewModel.isProcessingSubject)
                }

                Button {
                    focusedField = nil
                    let importStatus = PurchaseManager.shared.youtubeImportsRemaining
                    if importStatus <= 0 {
                        showingQuotaLimit = true
                    } else {
                        showingYouTubeInput = true
                    }
                } label: {
                    CreatorActionIcon(
                        systemName: "play.rectangle.fill",
                        colors: [.purple, .purple.opacity(0.8)]
                    )
                }
                .accessibilityIdentifier("youtubeImportButton")
                .accessibilityLabel("YouTube Import")
            }

            if viewModel.hasExportableContent {
                LazyVGrid(
                    columns: [GridItem(.adaptive(minimum: 58), spacing: 12)],
                    spacing: 12
                ) {
                    PhotosPicker(selection: $viewModel.profileImageSelection, matching: .images) {
                        CreatorActionIcon(
                            systemName: "person.crop.circle",
                            colors: [.orange, .orange.opacity(0.8)]
                        )
                    }
                    .accessibilityLabel("Add Profile Image")

                    Button {
                        focusedField = nil
                        let targetSize = viewModel.premiumMakerConfiguration.exportOptions.outputSize.cgSize
                        let content = PremiumPreviewComponentView(
                            premiumMakerConfiguration: viewModel.premiumMakerConfiguration,
                            width: targetSize.width,
                            height: targetSize.height
                        )
                        Task {
                            await viewModel.saveImageWithOverlay(content: content)
                        }
                    } label: {
                        CreatorActionIcon(
                            systemName: "square.and.arrow.down",
                            colors: [.green, .green.opacity(0.8)],
                            isLoading: viewModel.isSaving
                        )
                    }
                    .accessibilityLabel("Save to Photos")
                    .accessibilityValue(viewModel.isSaving ? "Busy" : "")
                    .disabled(viewModel.isSaving || viewModel.isPreparingShare || viewModel.isPreparingFileExport)

                    Button {
                        focusedField = nil
                        let targetSize = viewModel.premiumMakerConfiguration.exportOptions.outputSize.cgSize
                        let content = PremiumPreviewComponentView(
                            premiumMakerConfiguration: viewModel.premiumMakerConfiguration,
                            width: targetSize.width,
                            height: targetSize.height
                        )
                        Task {
                            await viewModel.shareImageWithOverlay(content: content)
                        }
                    } label: {
                        CreatorActionIcon(
                            systemName: "square.and.arrow.up",
                            colors: [.indigo, .indigo.opacity(0.8)],
                            isLoading: viewModel.isPreparingShare
                        )
                    }
                    .accessibilityLabel("Share Export")
                    .accessibilityValue(viewModel.isPreparingShare ? "Busy" : "")
                    .disabled(viewModel.isSaving || viewModel.isPreparingShare || viewModel.isPreparingFileExport)

                    Button {
                        focusedField = nil
                        let targetSize = viewModel.premiumMakerConfiguration.exportOptions.outputSize.cgSize
                        let content = PremiumPreviewComponentView(
                            premiumMakerConfiguration: viewModel.premiumMakerConfiguration,
                            width: targetSize.width,
                            height: targetSize.height
                        )
                        Task {
                            await viewModel.prepareFileExport(content: content)
                        }
                    } label: {
                        CreatorActionIcon(
                            systemName: "folder",
                            colors: [.teal, .teal.opacity(0.8)],
                            isLoading: viewModel.isPreparingFileExport
                        )
                    }
                    .accessibilityLabel("Export to Files")
                    .accessibilityValue(viewModel.isPreparingFileExport ? "Busy" : "")
                    .disabled(viewModel.isSaving || viewModel.isPreparingShare || viewModel.isPreparingFileExport)
                }

                TitleIdeasStripView(
                    ideas: viewModel.titleIdeas,
                    applyIdea: { idea in
                        focusedField = nil
                        viewModel.apply(idea: idea)
                        normalizeSelectedLayer()
                    }
                )

                ExportReadinessPanel(
                    report: viewModel.exportReport,
                    readinessReport: ThumbnailReadinessAnalyzer.analyze(
                        viewModel.premiumMakerConfiguration
                    ),
                    isChecking: viewModel.isCheckingExportSize,
                    canCheckSize: viewModel.hasExportableContent,
                    suggestions: viewModel.actionableSuggestions,
                    applySuggestion: { suggestion in
                        focusedField = nil
                        Task {
                            await viewModel.applyAsync(suggestion)
                            normalizeSelectedLayer()
                        }
                    }
                ) {
                    focusedField = nil
                    let targetSize = viewModel.premiumMakerConfiguration.exportOptions.outputSize.cgSize
                    let content = PremiumPreviewComponentView(
                        premiumMakerConfiguration: viewModel.premiumMakerConfiguration,
                        width: targetSize.width,
                        height: targetSize.height
                    )
                    Task {
                        await viewModel.checkExportSize(content: content)
                    }
                }
            }
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 20)
    }
    
    private var batchSettingsSection: some View {
        HStack(spacing: 12) {
            Button(action: {
                showingMacroSettings = true
            }) {
                HStack {
                    Image(systemName: "gearshape.2")
                    Text("Batch Settings")
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(
                    LinearGradient(colors: [Color(uiColor: .secondarySystemBackground), 
                                          Color(uiColor: .secondarySystemBackground).opacity(0.8)],
                                 startPoint: .leading,
                                 endPoint: .trailing)
                )
                .cornerRadius(8)
            }
            
            if viewModel.premiumMakerConfiguration.macroConfig.isEnabled {
                Button(action: {
                    focusedField = nil
                    Task {
                        await viewModel.generateBatchImages { text in
                            let targetSize = viewModel.premiumMakerConfiguration.exportOptions.outputSize.cgSize
                            return PremiumPreviewComponentView(
                                premiumMakerConfiguration: PremiumMakerConfigurationModel(
                                    selectedImage: viewModel.premiumMakerConfiguration.selectedImage,
                                    overlayText: text,
                                    selectedRatio: viewModel.premiumMakerConfiguration.selectedRatio,
                                    backgroundColor: viewModel.premiumMakerConfiguration.backgroundColor,
                                    textColor: viewModel.premiumMakerConfiguration.textColor,
                                    textSize: viewModel.premiumMakerConfiguration.textSize,
                                    verticalAlignment: viewModel.premiumMakerConfiguration.verticalAlignment,
                                    horizontalAlignment: viewModel.premiumMakerConfiguration.horizontalAlignment,
                                    textTransform: viewModel.premiumMakerConfiguration.textTransform,
                                    circularProfile: viewModel.premiumMakerConfiguration.circularProfile,
                                    profileTransform: viewModel.premiumMakerConfiguration.profileTransform,
                                    macroConfig: viewModel.premiumMakerConfiguration.macroConfig,
                                    selectedFont: viewModel.premiumMakerConfiguration.selectedFont,
                                    usesFallbackFont: viewModel.premiumMakerConfiguration.usesFallbackFont,
                                    exportOptions: viewModel.premiumMakerConfiguration.exportOptions
                                ),
                                width: targetSize.width,
                                height: targetSize.height
                            )
                        }
                    }
                }) {
                    HStack {
                        if viewModel.isSaving {
                            ProgressView()
                                .tint(.white)
                        }
                        Text(viewModel.isSaving ? "Generating..." : "Generate Batch")
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(
                        LinearGradient(colors: [.orange, .orange.opacity(0.8)],
                                     startPoint: .leading,
                                     endPoint: .trailing)
                    )
                    .foregroundColor(.white)
                    .cornerRadius(8)
                }
                .disabled(viewModel.isSaving || viewModel.premiumMakerConfiguration.selectedImage == nil)
            }
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 300)
    }
    
    private func premiumFeatureRow(icon: String, text: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 24))
                .foregroundStyle(.linearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 32)
            
            Text(text)
                .font(.body)
            
            Spacer()
            
            Image(systemName: "checkmark.circle.fill")
                .foregroundColor(.green)
        }
    }
}



//
//struct PremiumMakerView: View {
//    var body: some View {
//        
//    Text("Hello")
//    }
//    
//    
//    
//}


#Preview {
    PremiumMakerView()
}
