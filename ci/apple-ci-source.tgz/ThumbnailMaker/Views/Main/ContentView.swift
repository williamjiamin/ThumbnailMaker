//  ContentView.swift
//  ThumbnailMaker
//
//  Created by william on 2024/11/22.
//

import SwiftUI
import Foundation

struct ContentView: View {
    @State private var selectedTab: Tab

    init() {
        let startsOnPremium = ProcessInfo.processInfo.arguments.contains("-UITestStartPremiumTab")
        _selectedTab = State(initialValue: startsOnPremium ? .premium : .simpleMaker)
    }
    
    var body: some View {
        TabView(selection: $selectedTab) {
            SimpleMakerView()
                .tabItem {
                    Label("Simple", systemImage: "square.grid.2x2")
                        .accessibilityIdentifier("simpleMakerTab")
                }
                .tag(Tab.simpleMaker)
            
            PremiumMakerView()
                .tabItem {
                    Label("Premium", systemImage: "star.circle")
                        .accessibilityIdentifier("premiumMakerTab")
                }
                .tag(Tab.premium)
        }
        #if DEBUG && targetEnvironment(macCatalyst)
        .task {
            await MacAppStoreScreenshotRenderer.renderIfRequested()
        }
        #endif
    }
}

#Preview {
    ContentView()
}

#if DEBUG && targetEnvironment(macCatalyst)
private enum MacAppStoreScreenshotRenderer {
    private static let width: CGFloat = 1280
    private static let height: CGFloat = 800

    @MainActor
    static func renderIfRequested() {
        guard let path = renderPathArgument() else {
            return
        }

        let outputURL = URL(fileURLWithPath: path)

        do {
            try FileManager.default.createDirectory(
                at: outputURL.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )

            let content = MacAppStoreScreenshotView()
                .frame(width: width, height: height)

            let renderer = ImageRenderer(content: content)
            renderer.proposedSize = ProposedViewSize(width: width, height: height)
            renderer.scale = 1
            renderer.colorMode = .nonLinear

            guard let image = renderer.uiImage, let data = image.pngData() else {
                fputs("Could not render Mac App Store screenshot.\n", stderr)
                exit(1)
            }

            try data.write(to: outputURL, options: .atomic)
            exit(0)
        } catch {
            fputs("Could not write Mac App Store screenshot: \(error)\n", stderr)
            exit(1)
        }
    }

    private static func renderPathArgument() -> String? {
        let arguments = ProcessInfo.processInfo.arguments
        guard let flagIndex = arguments.firstIndex(of: "-RenderMacAppStoreScreenshot") else {
            return nil
        }

        let valueIndex = arguments.index(after: flagIndex)
        guard valueIndex < arguments.endIndex else {
            return nil
        }

        let value = arguments[valueIndex]
        return value.hasPrefix("-") ? nil : value
    }
}

private struct MacAppStoreScreenshotView: View {
    var body: some View {
        HStack(spacing: 0) {
            sidebar
            editor
            inspector
        }
        .frame(width: 1280, height: 800)
        .background(Color(uiColor: .systemBackground))
    }

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Thumbnail Maker")
                .font(.system(size: 22, weight: .bold))

            sidebarButton("Premium", systemImage: "star.fill", selected: true)
            sidebarButton("Templates", systemImage: "square.grid.2x2", selected: false)
            sidebarButton("Brand Kit", systemImage: "paintpalette.fill", selected: false)
            sidebarButton("Export", systemImage: "square.and.arrow.up", selected: false)

            Spacer()

            VStack(alignment: .leading, spacing: 8) {
                Text("Canvas")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                Text("YouTube Thumbnail")
                    .font(.headline)
                Text("1280 x 720")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(24)
        .frame(width: 220, height: 800)
        .background(Color(uiColor: .secondarySystemBackground))
    }

    private var editor: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Text("Premium Editor")
                    .font(.system(size: 28, weight: .bold))
                Spacer()
                Label("Snap", systemImage: "scope")
                Label("Undo", systemImage: "arrow.uturn.backward")
                Label("Redo", systemImage: "arrow.uturn.forward")
            }
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(.primary)

            ZStack {
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(uiColor: .tertiarySystemBackground))

                thumbnailCanvas
                    .frame(width: 720, height: 405)
                    .shadow(color: .black.opacity(0.22), radius: 22, y: 14)

                alignmentGuide(x: 640, y: 386, vertical: true)
                alignmentGuide(x: 628, y: 400, vertical: false)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            layerStrip
        }
        .padding(24)
        .frame(width: 740, height: 800)
        .background(Color(uiColor: .systemBackground))
    }

    private var thumbnailCanvas: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.06, green: 0.08, blue: 0.14),
                    Color(red: 0.10, green: 0.35, blue: 0.65),
                    Color(red: 1.00, green: 0.72, blue: 0.10)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            Circle()
                .fill(.white.opacity(0.16))
                .frame(width: 360, height: 360)
                .offset(x: 238, y: -90)

            VStack(alignment: .leading, spacing: 10) {
                Text("AI THUMBNAIL")
                    .font(.system(size: 28, weight: .heavy))
                    .foregroundStyle(.yellow)
                Text("BIG REVEAL")
                    .font(.system(size: 64, weight: .black))
                    .foregroundStyle(.white)
                    .shadow(color: .black.opacity(0.75), radius: 3, x: 3, y: 4)
                Text("Before / After in 10 minutes")
                    .font(.system(size: 24, weight: .bold))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .foregroundStyle(.black)
                    .background(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 4))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.leading, 46)

            ZStack {
                Circle()
                    .fill(LinearGradient(colors: [.orange, .pink], startPoint: .top, endPoint: .bottom))
                Image(systemName: "person.crop.circle.fill")
                    .font(.system(size: 102))
                    .foregroundStyle(.white.opacity(0.95))
            }
            .frame(width: 172, height: 172)
            .overlay(Circle().stroke(.white, lineWidth: 8))
            .offset(x: 228, y: 92)

            selectionChrome
                .frame(width: 392, height: 140)
                .offset(x: -136, y: -28)
        }
        .clipShape(RoundedRectangle(cornerRadius: 6))
    }

    private var selectionChrome: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 6)
                .stroke(.white, style: StrokeStyle(lineWidth: 3, dash: [8, 6]))

            let handlePoints = [
                CGPoint(x: -196, y: -70),
                CGPoint(x: 196, y: -70),
                CGPoint(x: -196, y: 70),
                CGPoint(x: 196, y: 70)
            ]

            ForEach(handlePoints.indices, id: \.self) { index in
                Circle()
                    .fill(.white)
                    .frame(width: 16, height: 16)
                    .shadow(radius: 2)
                    .offset(x: handlePoints[index].x, y: handlePoints[index].y)
            }

            Image(systemName: "arrow.clockwise")
                .font(.system(size: 18, weight: .bold))
                .padding(8)
                .foregroundStyle(.black)
                .background(.white)
                .clipShape(Circle())
                .offset(x: 0, y: -92)
        }
    }

    private var layerStrip: some View {
        HStack(spacing: 12) {
            layerChip("Text", "BIG REVEAL", selected: true)
            layerChip("Image", "Face Cutout", selected: false)
            layerChip("Shape", "Gradient Glow", selected: false)
            layerChip("Sticker", "Arrow", selected: false)
        }
        .frame(height: 84)
    }

    private var inspector: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Inspector")
                .font(.system(size: 24, weight: .bold))

            inspectorGroup("Layer", rows: [
                ("Name", "Headline"),
                ("Blend", "Normal"),
                ("Opacity", "100%")
            ])

            inspectorGroup("Text Style", rows: [
                ("Font", "Impact"),
                ("Outline", "8 px"),
                ("Shadow", "Strong")
            ])

            inspectorGroup("Export", rows: [
                ("Format", "PNG"),
                ("Preset", "YouTube"),
                ("Quality", "100%")
            ])

            Spacer()

            HStack {
                Label("Ready", systemImage: "checkmark.seal.fill")
                    .foregroundStyle(.green)
                    .font(.headline)
                Spacer()
                Text("Small preview")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(24)
        .frame(width: 320, height: 800)
        .background(Color(uiColor: .secondarySystemBackground))
    }

    private func sidebarButton(_ title: String, systemImage: String, selected: Bool) -> some View {
        Label(title, systemImage: systemImage)
            .font(.headline)
            .foregroundStyle(selected ? .white : .primary)
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(selected ? Color.accentColor : Color.clear)
            .clipShape(RoundedRectangle(cornerRadius: 8))
    }

    private func layerChip(_ title: String, _ subtitle: String, selected: Bool) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.caption.weight(.bold))
                .foregroundStyle(.secondary)
            Text(subtitle)
                .font(.headline)
        }
        .padding(14)
        .frame(width: 162, height: 72, alignment: .leading)
        .background(selected ? Color.accentColor.opacity(0.16) : Color(uiColor: .secondarySystemBackground))
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(selected ? Color.accentColor : Color.clear, lineWidth: 2)
        )
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }

    private func inspectorGroup(_ title: String, rows: [(String, String)]) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.headline)
            ForEach(rows, id: \.0) { row in
                HStack {
                    Text(row.0)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text(row.1)
                        .fontWeight(.semibold)
                }
                .font(.subheadline)
            }
        }
        .padding(16)
        .background(Color(uiColor: .systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }

    private func alignmentGuide(x: CGFloat, y: CGFloat, vertical: Bool) -> some View {
        Rectangle()
            .fill(Color.cyan.opacity(0.75))
            .frame(width: vertical ? 2 : 640, height: vertical ? 440 : 2)
            .position(x: x, y: y)
    }
}
#endif
