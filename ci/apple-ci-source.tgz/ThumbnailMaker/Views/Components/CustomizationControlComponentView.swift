//
//  CustomizationControlComponentView.swift
//  ThumbnailMaker
//
//  Created by william on 2024/11/28.
//

import SwiftUI

struct CustomizationControlComponentView: View {
    @Binding var configuration: SimpleMakerConfigurationModel
    @Binding var showsSafeZoneGuide: Bool
    @State private var showingRatioDrawer = false
    let isPremium: Bool
    
    var body: some View {
        VStack(spacing: 16) {
            // Canvas Settings Section
            HStack(spacing: 0) {
                // Left side - Aspect Ratio Button
                Button(action: {
                    withAnimation {
                        showingRatioDrawer = true
                    }
                }) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Aspect Ratio")
                                .font(.headline)
                            Text(configuration.selectedRatio.rawValue)
                                .font(.subheadline)
                                .foregroundColor(.accessibleSecondaryText)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        
                        Spacer()
                        
                        Image(systemName: "chevron.up.chevron.down")
                            .foregroundColor(.blue)
                    }
                    .padding(.horizontal)
                }
                .frame(maxWidth: .infinity)
                
                Divider()
                    .frame(height: 40)
                    .padding(.horizontal)
                
                // Right side - Background Color
                VStack(alignment: .center, spacing: 4) {
                    Image(systemName: "paintpalette.fill")
                        .font(.headline)
                        .foregroundColor(.accessibleSecondaryText)
                        .accessibilityHidden(true)
                    ColorPicker("", selection: $configuration.backgroundColor)
                        .labelsHidden()
                        .frame(minWidth: 44, minHeight: 44)
                        .accessibilityLabel("Background color")
                        .accessibilityValue("Custom color")
                        .accessibilityHint("Opens the color picker to change the thumbnail background.")
                }
                .frame(width: 100, alignment: .center)
                .padding(.trailing)
            }
            .padding(.vertical, 8)

            Divider()

            ExportSettingsSummaryRow(
                selectedRatio: $configuration.selectedRatio,
                options: $configuration.exportOptions
            )

            if let safeZone = configuration.exportOptions.activeSafeZone {
                Divider()

                SafeZoneGuideToggle(
                    isOn: $showsSafeZoneGuide,
                    safeZone: safeZone
                )
            }
        }
        .background(Color(uiColor: .secondarySystemBackground))
        .cornerRadius(12)
        .sheet(isPresented: $showingRatioDrawer) {
            AspectRatioDrawerView(
                selectedRatio: $configuration.selectedRatio,
                isPresented: $showingRatioDrawer,
                onDismiss: {
                    showingRatioDrawer = false
                }
            )
            .presentationDetents([.height(300)])
            .presentationDragIndicator(.visible)
        }
    }
}

#Preview {
    CustomizationControlComponentView(
        configuration: .constant(SimpleMakerConfigurationModel()),
        showsSafeZoneGuide: .constant(true),
        isPremium: false
    )
}
