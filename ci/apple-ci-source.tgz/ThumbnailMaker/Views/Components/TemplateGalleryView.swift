//
//  TemplateGalleryView.swift
//  ThumbnailMaker
//

import SwiftUI

struct TemplateGalleryView: View {
    @Environment(\.dismiss) private var dismiss
    let templates: [ThumbnailTemplate]
    let onSelect: (ThumbnailTemplate) -> Void

    init(
        templates: [ThumbnailTemplate] = ThumbnailTemplate.builtIns,
        onSelect: @escaping (ThumbnailTemplate) -> Void
    ) {
        self.templates = templates
        self.onSelect = onSelect
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 18) {
                    ForEach(ThumbnailTemplateCategory.allCases, id: \.self) { category in
                        let categoryTemplates = templates.filter { $0.category == category }
                        if !categoryTemplates.isEmpty {
                            templateSection(category: category, templates: categoryTemplates)
                        }
                    }
                }
                .padding(20)
            }
            .navigationTitle("Templates")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }

    private func templateSection(
        category: ThumbnailTemplateCategory,
        templates: [ThumbnailTemplate]
    ) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Label(category.title, systemImage: category.systemImage)
                .font(.headline)
                .foregroundStyle(.primary)

            LazyVGrid(
                columns: [GridItem(.adaptive(minimum: 180), spacing: 12)],
                alignment: .leading,
                spacing: 12
            ) {
                ForEach(templates) { template in
                    templateButton(template)
                }
            }
        }
    }

    private func templateButton(_ template: ThumbnailTemplate) -> some View {
        Button {
            onSelect(template)
            dismiss()
        } label: {
            VStack(alignment: .leading, spacing: 10) {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(template.document.canvas.backgroundColor.color)
                    .overlay(alignment: .center) {
                        Text(template.document.text.value)
                            .font(.system(size: 18, weight: .black, design: .rounded))
                            .foregroundStyle(template.document.text.color.color)
                            .lineLimit(2)
                            .minimumScaleFactor(0.6)
                            .multilineTextAlignment(.center)
                            .padding(12)
                    }
                    .aspectRatio(templateAspectRatio(template), contentMode: .fit)

                VStack(alignment: .leading, spacing: 3) {
                    Text(template.name)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)

                    Text(templatePresetSummary(template))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(uiColor: .secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .stroke(Color.primary.opacity(0.08), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier("templateCard-\(template.id)")
        .accessibilityLabel("Apply \(template.name) template")
        .accessibilityValue(template.category.title)
        .accessibilityHint("Keeps your current images and applies this layout, text style, export preset, and canvas size.")
        .accessibilityAddTraits(.isButton)
    }

    private func templateAspectRatio(_ template: ThumbnailTemplate) -> CGFloat {
        let aspectRatio = AspectRatio(rawValue: template.document.canvas.aspectRatioRawValue) ?? .ratio16_9
        return aspectRatio.value
    }

    private func templatePresetSummary(_ template: ThumbnailTemplate) -> String {
        guard let preset = ThumbnailExportPreset.all.first(where: {
            $0.id == template.document.export.presetID
        }) else {
            return template.document.export.presetID
        }

        return "\(preset.name) · \(preset.size.displayText)"
    }
}

private extension ThumbnailTemplateCategory {
    var title: String {
        switch self {
        case .youtube:
            "YouTube"
        case .shortForm:
            "Short Form"
        case .podcast:
            "Podcast"
        case .gaming:
            "Gaming"
        case .vlog:
            "Vlog"
        }
    }

    var systemImage: String {
        switch self {
        case .youtube:
            "play.rectangle.fill"
        case .shortForm:
            "rectangle.portrait.fill"
        case .podcast:
            "mic.fill"
        case .gaming:
            "gamecontroller.fill"
        case .vlog:
            "camera.fill"
        }
    }
}

#Preview {
    TemplateGalleryView { _ in }
}
